function EntityTakeDamage(target,info)
	local attacker = info:GetAttacker()
	if target:IsPlayer() and attacker:IsPlayer() then
		if info:GetInflictor():GetClass() == "crossbow_bolt" then
		    info:SetDamage(125)
		end
	end
end

hook.Add("EntityTakeDamage","EntityTakeDamage",EntityTakeDamage)
--Code by Sninctbur
-- hello there :) im a stupid ni