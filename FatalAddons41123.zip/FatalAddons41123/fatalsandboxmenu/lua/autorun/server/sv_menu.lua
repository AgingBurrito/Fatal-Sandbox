util.AddNetworkString("purchase")
util.AddNetworkString("equip")

TTN = {
	"76561198953637100", --gopnik
	"76561199014408520", --cyber
	"76561198827970113", --corvus
	"76561198375490010", --bright
	"76561198053255329", --bhop
	"76561199149565191", --g nuts
	"76561198113505666", --burrito
}

util.AddNetworkString("f4menu")
hook.Add("ShowSpare2", "f4menu", function(ply)
	net.Start("f4menu")
	net.Send(ply)
end)
util.AddNetworkString("f3menu")
hook.Add("ShowSpare1", "f3menu", function(ply)
	net.Start("f3menu")
	net.Send(ply)
end)
util.AddNetworkString("Arctic")
net.Receive("Arctic", function (len, ply)
	ply:SetModel("models/player/arctic.mdl")
	net.Start("equip")
	net.Send(ply)
end)
util.AddNetworkString("SuperHot")
net.Receive("SuperHot", function (len, ply)
	ply:SetModel("models/player/corpse1.mdl")
	ply:SetPData("playermodel", "models/player/corpse1.mdl")
	net.Start("equip")
	net.Send(ply)
end)
util.AddNetworkString("Daedric")
net.Receive("Daedric", function (len, ply)
	local cash = ply:GetNWInt("playerCash")
	local daedric = ply:GetNWInt("playerDaedric")
	-- print(cash)
	-- print(ply:GetPData("playerDaedric"))
	-- print(ply:GetNWInt("playerDaedric"))
	if tonumber(daedric) == 1 then
		ply:SetModel("models/player/daedric.mdl")
		ply:SetNWInt("playerDaedric", 1)
		ply:SetPData("playerDaedric", 1)
		ply:SetPData("playermodel", "models/player/daedric.mdl")
		-- print(ply:GetPData("playermodel"))
		-- print(ply:Nick() .. " equiped daedric")
		net.Start("equip")
		net.Send(ply)
	elseif tonumber(cash) >= 100000 then 
		ply:SetModel("models/player/daedric.mdl")
		ply:SetNWInt("playercash", ply:GetNWInt("playerCash") - 100000)
		ply:SetPData("playerCash", ply:GetNWInt("playerCash") )
		ply:SetNWInt("playerDaedric", 1)
		ply:SetPData("playerDaedric", 1)
		-- print(ply:GetPData("playerDaedric"))
		-- print(daedric)
		-- print(ply:Nick().. " bought daedric")
		net.Start("purchase")
		net.Send(ply)
	else
		ply:EmitSound("buttons/weapon_cant_buy.wav")
		-- print(ply:Nick().. " needs 10k for daedric")
	end
end)

util.AddNetworkString("NCR")
net.Receive("NCR", function (len, ply)
	local cash = ply:GetNWInt("playerCash")
	local NCR = ply:GetNWInt("playerNCR")
	local cost = 10000
	local name = "NCR"
	-- print(ply:GetNWInt("playerCash"))
	-- print(ply:GetPData("playerNCR"))
	-- print(ply:GetNWInt("playerNCR"))
	if tonumber(NCR) == 1 then
		ply:SetModel("models/gonzo/ncrrangerimproved/ncrrangerimproved.mdl")
		ply:SetNWInt("playerNCR", 1)
		ply:SetPData("playerNCR", 1)
		ply:SetPData("playermodel", "models/gonzo/ncrrangerimproved/ncrrangerimproved.mdl")
		-- print(ply:Nick() .. " equiped NCR")
		net.Start("equip")
		net.Send(ply)
	elseif tonumber(ply:GetNWInt("playerCash")) >= cost then 
		ply:SetModel("models/gonzo/ncrrangerimproved/ncrrangerimproved.mdl")
		ply:SetNWInt("playerCash", cash - cost)
		-- print(ply:GetNWInt("playerCash"), ply:GetNWInt("playerCash") - cost)
		ply:SetPData("playerCash", ply:GetNWInt("playerCash"))
		ply:SetNWInt("playerNCR", 1)
		ply:SetPData("playerNCR", 1)
		-- print(ply:GetPData("playerNCR"))
		-- print(ply:GetNWInt("playerNCR"))
		-- print(ply:Nick().. " bought NCR")
		net.Start("purchase")
		net.Send(ply)
	else
		ply:EmitSound("buttons/weapon_cant_buy.wav")
		-- print(ply:Nick().. " needs 10k for NCR")
	end
end)
util.AddNetworkString("Slayer")
net.Receive("Slayer", function (len, ply)
    local kd = tonumber(ply:GetNWInt("playerKills")) / tonumber(ply:GetNWInt("playerDeaths"))
    if tonumber(ply:GetNWInt("playerKills")) >= 1000 and kd >= 2 then
	    ply:SetModel("models/outlaw/DoomEternal/DoomSlayerEternal.mdl")
	    ply:SetPData("playermodel", "models/outlaw/DoomEternal/DoomSlayerEternal.mdl")
	    net.Start("equip")
    	net.Send(ply)
	else
	    ply:EmitSound("buttons/weapon_cant_buy.wav")
	    ply:PrintMessage(HUD_PRINTTALK, "You're not good enough.")
    end
end)
util.AddNetworkString("ttn")
net.Receive("ttn", function (len, ply)
    print(ply:SteamID64())
	for k, v in pairs(TTN) do 
		if v == ply:SteamID64() then 
			ply:SetPData("playermodel", "models/player/combine_super_soldier.mdl")
			ply:SetNWInt("playermodel", "models/player/combine_super_soldier.mdl")
			ply:SetModel("models/player/combine_super_soldier.mdl")
			net.Start("equip")
			net.Send(ply)
			return
		end
	end
	ply:EmitSound("buttons/weapon_cant_buy.wav")
	ply:PrintMessage(HUD_PRINTTALK, "You're not TTN.")
end)

util.AddNetworkString("gopnik")
net.Receive("gopnik", function (len, ply) 
	if ply:SteamID64() == "76561198953637100" then 
		ply:SetPData("playermodel", "models/player/police.mdl")
		ply:SetNWInt("playermodel", "models/player/police.mdl")
		ply:SetModel("models/player/police.mdl")
		net.Start("equip")
		net.Send(ply)
		ply:PrintMessage(HUD_PRINTTALK, "Welcome, glorious fart master.")
	else
		ply:EmitSound("buttons/weapon_cant_buy.wav")
		ply:PrintMessage(HUD_PRINTTALK, "YOU'RE NOT THE FART MASTER!!!")
		return
	end
end)