local function calch(h)
	local value = ScrH() / h
	return value 
end

local function calcw(w)
	local value = ScrW() / w
	return value 
end

local function wpnchangesfunc()
	if (frame) then return end 
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetVisible(true)
	frame:MakePopup()
	frame:Center()
	frame:SetTitle("")
	frame:SetPaintShadow(true)
	frame.Paint = function(self, w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 250))
		draw.SimpleTextOutlined("Universal changes:", "TargetID", 																ScrW() / calcw(100), ScrH() / calch(75), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("No bullet spread, everything is a lazer beam", "TargetID", 									ScrW() / calcw(100), ScrH() / calch(100), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("The arms and legs take the same damage as the chest", "TargetID",								ScrW() / calcw(100), ScrH() / calch(115), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Only some weapons headshot ", "TargetID", 														ScrW() / calcw(100), ScrH() / calch(130), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Randomized damage removed", "TargetID", 														ScrW() / calcw(100), ScrH() / calch(145), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("You can sprint and shoot", "TargetID", 														ScrW() / calcw(100), ScrH() / calch(160), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("ADS isn't real except for snipers", "TargetID", 												ScrW() / calcw(100), ScrH() / calch(175), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		
		draw.SimpleTextOutlined("Assault Rifles:", "TargetID", 																	ScrW() / calcw(100), ScrH() / calch(275), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("These are the easiest guns to use so you will probably want to use them", "TargetID", 			ScrW() / calcw(100), ScrH() / calch(300), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("There are only 2 types of rifles, every single gun is 1 of those 2", "TargetID",				ScrW() / calcw(100), ScrH() / calch(315), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("There are 1000rpm and 25dmg rifles and 650rpm 30dmg rifles", "TargetID", 						ScrW() / calcw(100), ScrH() / calch(330), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("The 1000rpm has better dps because it is harder to use due to mag dumping faster", "TargetID", ScrW() / calcw(100), ScrH() / calch(345), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		
		draw.SimpleTextOutlined("LMGs:", "TargetID", 																			ScrW() / calcw(100), ScrH() / calch(375), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Weaker assault rifles with bigger mags", "TargetID", 											ScrW() / calcw(100), ScrH() / calch(400), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Crutch/noob type gun", "TargetID", 															ScrW() / calcw(100), ScrH() / calch(415), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Good for destroying props though", "TargetID", 												ScrW() / calcw(100), ScrH() / calch(430), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))

		draw.SimpleTextOutlined("Pump Shotguns:", "TargetID", 																	ScrW() / calcw(100), ScrH() / calch(475), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Pellet spread is consistent", "TargetID", 														ScrW() / calcw(100), ScrH() / calch(500), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("120 max damage with 20 pellets doing 6 dmg each", "TargetID", 									ScrW() / calcw(100), ScrH() / calch(515), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("4 pellets go directly in the center so at any range you are guarnteed 24 damage", "TargetID", 	ScrW() / calcw(100), ScrH() / calch(530), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("They fire slow but the delay can be skipped by weapon swapping", "TargetID", 					ScrW() / calcw(100), ScrH() / calch(545), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))

		draw.SimpleTextOutlined("Bolt Snipers:", "TargetID", 																	ScrW() / calcw(100), ScrH() / calch(575), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("100dmg", "TargetID", 																			ScrW() / calcw(100), ScrH() / calch(600), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Can headshot", "TargetID", 																	ScrW() / calcw(100), ScrH() / calch(615), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Inaccurate when noscoping", "TargetID", 														ScrW() / calcw(100), ScrH() / calch(630), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("5 round mags", "TargetID", 																	ScrW() / calcw(100), ScrH() / calch(645), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))									
	end
end

local function unichangefunc()
	if (frame) then return end 
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetVisible(true)
	frame:MakePopup()
	frame:Center()
	frame:SetTitle("")
	frame:SetPaintShadow(true)
	frame.Paint = function(self, w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 250))
		draw.SimpleTextOutlined("Speed cap removed, meaning you can bunny hop", "TargetID",														ScrW() / calcw(100), ScrH() / calch(100), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("You get all your health back when you kill someone", "TargetID",												ScrW() / calcw(100), ScrH() / calch(125), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("All of your weapons are reloaded when you kill someone", "TargetID",											ScrW() / calcw(100), ScrH() / calch(150), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Hold C to make a loadout so you spawn with guns", "TargetID",													ScrW() / calcw(100), ScrH() / calch(175), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Hold C to change your crosshair", "TargetID",																	ScrW() / calcw(100), ScrH() / calch(200), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("There is a radial menu mod you can access with +gb-radial meaning you can make a weapon wheel", "TargetID",	ScrW() / calcw(100), ScrH() / calch(225), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Viewmod is installed so you can change your viewmodel", "TargetID",											ScrW() / calcw(100), ScrH() / calch(250), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("You can edit or disable the custom hud in spawnmenu options", "TargetID",										ScrW() / calcw(100), ScrH() / calch(275), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("There is a boxed version of the ESP into spawnmenu options", "TargetID",										ScrW() / calcw(100), ScrH() / calch(300), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("When you get a 25 killstreak you get a nuke", "TargetID",														ScrW() / calcw(100), ScrH() / calch(325), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("F3 allows you to change your playermodel with money", "TargetID",												ScrW() / calcw(100), ScrH() / calch(350), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("You get money when you kill someone, 100 regular 150 on headshot", "TargetID",									ScrW() / calcw(100), ScrH() / calch(375), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("F4 shows you your all-time stats", "TargetID",																	ScrW() / calcw(100), ScrH() / calch(400), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Props can be destroyed by bullets so prop blocking is impossible", "TargetID",									ScrW() / calcw(100), ScrH() / calch(425), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("No fall damage", "TargetID",																					ScrW() / calcw(100), ScrH() / calch(450), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("sv_airaccelrate is 999 meaning you can airstrafe", "TargetID",						ScrW() / calcw(100), ScrH() / calch(475), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
	end
end

local function contactfunc()
	if (frame) then return end 
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetVisible(true)
	frame:MakePopup()
	frame:Center()
	frame:SetTitle("")
	frame:SetPaintShadow(true)
	frame.Paint = function(self, w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 250))
		draw.SimpleTextOutlined("Steam profile: https://steamcommunity.com/profiles/76561198113505666/", "TargetID",	ScrW() / calcw(960), ScrH() / calch(500), Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Discord: AgingBurrito#9450", "TargetID", 												ScrW() / calcw(960), ScrH() / calch(600), Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
	end
end

local function fatalinfo()
	if (frame) then return end 
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetVisible(true)
	frame:MakePopup()
	frame:Center()
	frame:SetTitle("")
	frame:SetPaintShadow(true)
	frame.Paint = function(self, w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 250))
	end

	local wpnchanges = vgui.Create("DButton", frame)
	wpnchanges:SetSize(ScrW() / calcw(100), ScrH() / calch(50))
	wpnchanges:SetText("Weapon Info")
	wpnchanges:SetPos(ScrW() / calcw(200) , ScrH() / calch(200)  )
	function wpnchanges:DoClick() 
		frame:Close()
		wpnchangesfunc()
	end

	local unichange = vgui.Create("DButton", frame)
	unichange:SetSize(ScrW() / calcw(100), ScrH() / calch(50))
	unichange:SetText("Server Info")
	unichange:SetPos(ScrW() / calcw(200) , ScrH() / calch(400)  )
	function unichange:DoClick() 
		frame:Close()
		unichangefunc()
	end

	local contact = vgui.Create("DButton", frame)
	contact:SetSize(ScrW() / calcw(100), ScrH() / calch(50))
	contact:SetText("Contact Owner")
	contact:SetPos(ScrW() / calcw(200) , ScrH() / calch(600)  )
	function contact:DoClick() 
		frame:Close()
		contactfunc()
	end
end

net.Receive("info", fatalinfo)