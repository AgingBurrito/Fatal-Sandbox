local function calch(h)
	local value = ScrH() / h
	return value 
end

local function calcw(w)
	local value = ScrW() / w
	return value 
end

local function duelmenu()
	if (frame) then return end 
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetVisible(true)
	frame:MakePopup()
	frame:Center()
	frame:SetTitle("")
	frame:SetPaintShadow(true)
	frame.Paint = function(self, w, h )
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 250))
		draw.SimpleTextOutlined("Duels", "TargetID",														ScrW() / calcw(960), ScrH() / calch(100), Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Opponent:", "TargetID",													ScrW() / calcw(960), ScrH() / calch(200), Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Arena:", "TargetID",														ScrW() / calcw(960), ScrH() / calch(230), Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
		draw.SimpleTextOutlined("Ruleset:", "TargetID",														ScrW() / calcw(960), ScrH() / calch(260), Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 0 ))
	end
	local DComboBox = vgui.Create( "DComboBox", frame )
	DComboBox:SetPos(1010, 200)
	DComboBox:SetSize(100, 20)
	for k,v in pairs(player.GetAll()) do
		DComboBox:AddChoice(v:Name())
	end
end

net.Receive("duel", duelmenu)