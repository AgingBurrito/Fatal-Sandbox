net.Receive("f4menu", function()
	if (!frame) then 
		local kills = LocalPlayer():GetNWInt("playerKills")
		local deaths = LocalPlayer():GetNWInt("playerDeaths")
		local kd = 5
		if deaths == 0 then 
		 	kd = kills 
		else local mult = 10^(1)
  			kd = math.floor(kills / deaths * mult + 0.5) / mult
		end
		local frame = vgui.Create("DFrame")
		frame:SetSize(ScrW(), ScrH())
		frame:SetVisible(true)
		frame:MakePopup()
		frame:Center()
		frame:SetTitle("")
		frame:SetPaintShadow(true)
		frame.Paint = function(self, w, h )
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 200))
			draw.DrawText("Kills: " .. kills, "TargetID", ScrW() * 0.5, ScrH() * 0.25, color_white, TEXT_ALIGN_CENTER )
			draw.DrawText("Deaths: " .. deaths, "TargetID", ScrW() * 0.5, ScrH() * 0.20, color_white, TEXT_ALIGN_CENTER )
			draw.DrawText("KD: " .. kd, "TargetID", ScrW() * 0.5, ScrH() * 0.15, color_white, TEXT_ALIGN_CENTER )
		end
		local icon = vgui.Create( "DModelPanel", frame )
		icon:SetPos( ScrW() * 0.5, ScrH() * 0.1 )
		icon:SetSize( 200, 200 )
		icon:SetModel( LocalPlayer():GetModel() )		
		function icon:LayoutEntity( Entity ) return end 
		frame:SetDeleteOnClose(true)

		--local weaponstats = vgui.Create("DButton", frame, "Weapon Stats")
		--weaponstats:SetSize(ScrW() * 0.1, ScrH() * 0.05)
		--weaponstats:SetPos(ScrW() * 0.38, ScrH() * 0.3)
		--weaponstats:SetText("Weapon Stats")
		--function weaponstats:DoClick()
			--frame:Close()
			--local f = vgui.Create( "DFrame" )
		--	f:SetSize( ScrW() * 0.2, ScrH() * 0.25 )
		--	f:Center()
		--	f:MakePopup()
		--	f:SetTitle("Weapon Stats")
		--	local list = vgui.Create("DListView", f,  "wstats")
		--	list:SetSize(ScrW() * 0.2, ScrH() * 0.2)
			--list:SetVisible(true)
		--	list:Center()
			--list:AddColumn("Weapon")
		--	list:AddColumn("Kills")
			--list:AddColumn("Shots Fired")
			--list:AddColumn("Hits")
		--	list:AddColumn("Headshots")
			--list:AddColumn("Accuracy")

		--	local gun = "AK-47"
		--	local kills = LocalPlayer():GetNWInt(gun .. "kills")
			--local shots = LocalPlayer():GetNWInt(gun .. "shots")
		--	local hits = LocalPlayer():GetNWInt(gun .. "hits")
			--local hs = LocalPlayer():GetNWInt(gun .. "headshots")
			--local accuracy = hits / shots
			--local accuracy = math.floor (accuracy * 100) 
			--list:AddLine(gun, kills, shots, hits, hs, accuracy.. "%")
			--local gun = "Barret M98B"
			--local kills = LocalPlayer():GetNWInt(gun .. "kills")
			--local shots = LocalPlayer():GetNWInt(gun .. "shots")
			--local hits = LocalPlayer():GetNWInt(gun .. "hits")
			--local hs = LocalPlayer():GetNWInt(gun .. "headshots")
		--	--local accuracy = hits / shots
			--local accuracy = math.floor (accuracy * 100) 
			--list:AddLine(gun, kills, shots, hits, hs, accuracy.. "%")
			--local gun = "HK 416"
			--local kills = LocalPlayer():GetNWInt(gun .. "kills")
			--local shots = LocalPlayer():GetNWInt(gun .. "shots")
			--local hits = LocalPlayer():GetNWInt(gun .. "hits")
			--local hs = LocalPlayer():GetNWInt(gun .. "headshots")
			--local accuracy = hits / shots
			--local accuracy = math.floor (accuracy * 100) 
			--list:AddLine(gun, kills, shots, hits, hs, accuracy.. "%")

		--end
	end
end)

net.Receive("f3menu", function()
	if (!frame) then
		local player = LocalPlayer()
		local black = Color(0,0,0,200)
		local cash = LocalPlayer():GetNWInt("playerCash")
		local frame = vgui.Create("DFrame")
		frame:SetSize(ScrW(), ScrH())
		frame:SetVisible(true)
		frame:MakePopup()
		frame:Center()
		frame:SetTitle("")
		frame:SetPaintShadow(true)
		frame.Paint = function(self, w, h )
			draw.RoundedBox(0, 0, 0, w, h, black)
			draw.DrawText("Cash: $" .. cash, "TargetID", ScrW() * 0.5, ScrH() * 0.25, color_white, TEXT_ALIGN_CENTER )
			if tonumber(LocalPlayer():GetNWInt("playerDaedric")) == 0 then
				draw.DrawText("$100,000", "TargetID", ScrW() * 0.33, ScrH() * 0.66, color_white, TEXT_ALIGN_CENTER )
			end
			if tonumber(LocalPlayer():GetNWInt("playerNCR")) == 0 then
				draw.DrawText("$10,000", "TargetID", ScrW() * 0.328, ScrH() * 0.5, color_white, TEXT_ALIGN_CENTER )
			end
			draw.DrawText("Must have 1,000 kills or more and a KD of 2 or more", "TargetID", ScrW() * 0.85, ScrH() * 0.79, color_white, TEXT_ALIGN_CENTER )
			draw.DrawText("Must be a member of TTN", "TargetID", ScrW() * 0.795, ScrH() * 0.565, color_white, TEXT_ALIGN_CENTER )
			draw.DrawText("Must be the fart master", "TargetID", ScrW() * 0.81, ScrH() * 0.34, color_white, TEXT_ALIGN_CENTER )
		end
		frame:SetDeleteOnClose(false)
		local Panel1 = vgui.Create( "DPanel", frame )
		Panel1:SetPos( ScrW() * 0.2, ScrH() * 0.2 )
		Panel1:SetSize( 200, 200 )
		Panel1:SetBackgroundColor(color_white)
		local icon1 = vgui.Create( "DModelPanel", frame )
		icon1:SetPos( ScrW() * 0.2, ScrH() * 0.2 )
		icon1:SetSize( 200, 200 )
		icon1:SetModel("models/player/corpse1.mdl")
		function icon1:LayoutEntity( Entity ) return end 
		local check1 = vgui.Create("DImage", icon1)	-- Add image to Frame
		check1:SetPos(0, 0)	-- Move it into frame
		check1:SetSize(32, 32)	-- Size it to 150x150
		check1:SetImage("icon16/accept.png")
		local button1 = vgui.Create("DButton", frame)
		button1:SetPos(ScrW()*0.31,ScrH()*0.32) 
		button1:SetText("Equip")
		button1:SetSize(75,25)
		function button1:DoClick() -- Defines what should happen when the label is clicked
			net.Start("SuperHot")
			net.SendToServer(ply)
		end

		local Panel2 = vgui.Create( "DPanel", frame )
		Panel2:SetPos( ScrW() * 0.2, ScrH() * 0.4 )
		Panel2:SetSize( 200, 200 )
		Panel2:SetBackgroundColor(color_white)
		local icon2 = vgui.Create( "DModelPanel", frame )
		icon2:SetPos( ScrW() * 0.2, ScrH() * 0.4 )
		icon2:SetSize( 200, 200 )
		icon2:SetModel("models/gonzo/ncrrangerimproved/ncrrangerimproved.mdl")
		function icon2:LayoutEntity( Entity ) return end
		local button2 = vgui.Create("DButton", frame)
		button2:SetIcon("icon16/money.png")
		button2:SetPos(ScrW()*0.31,ScrH()*0.52) 
		button2:SetText("Buy")
		button2:SetSize(75,25)
		function button2:DoClick() -- Defines what should happen when the label is clicked
			net.Start("NCR")
			net.SendToServer(ply) 
		end
		if tonumber(LocalPlayer():GetNWInt("playerNCR")) == 1 then
			local check2 = vgui.Create("DImage", icon2)	-- Add image to Frame
			check2:SetPos(0, 0)	-- Move it into frame
			check2:SetSize(32, 32)	-- Size it to 150x150
			check2:SetImage("icon16/accept.png")
			button2:SetIcon()
			button2:SetText("Equip")
		else
			local cancel2 = vgui.Create("DImage", icon2	)	-- Add image to Frame
			cancel2:SetPos(0, 0)	-- Move it into frame
			cancel2:SetSize(32, 32)	-- Size it to 150x150
			cancel2:SetImage("icon16/cancel.png")
		end

		local Panel3 = vgui.Create( "DPanel", frame )
		Panel3:SetPos( ScrW() * 0.2, ScrH() * 0.6 )
		Panel3:SetSize( 200, 200 )
		Panel3:SetBackgroundColor(color_white)
		local icon3 = vgui.Create( "DModelPanel", frame )
		icon3:SetPos( ScrW() * 0.2, ScrH() * 0.6 )
		icon3:SetSize( 200, 200 )
		icon3:SetModel("models/player/daedric.mdl")
		function icon3:LayoutEntity( Entity ) return end
		local button3 = vgui.Create("DButton", frame)
		button3:SetIcon("icon16/money.png")
		button3:SetPos(ScrW()*0.31,ScrH()*0.68) 
		button3:SetText("Buy")
		button3:SetSize(75,25)
		function button3:DoClick() -- Defines what should happen when the label is clicked
			net.Start("Daedric")
			net.SendToServer(ply) 
		end
		if tonumber(LocalPlayer():GetNWInt("playerDaedric")) == 1 then
			local check3 = vgui.Create("DImage", icon3)	-- Add image to Frame
			check3:SetPos(0, 0)	-- Move it into frame
			check3:SetSize(32, 32)	-- Size it to 150x150
			check3:SetImage("icon16/accept.png")
			button3:SetIcon()
			button3:SetText("Equip")
		else
			local cancel3 = vgui.Create("DImage", icon3	)	-- Add image to Frame
			cancel3:SetPos(0, 0)	-- Move it into frame
			cancel3:SetSize(32, 32)	-- Size it to 150x150
			cancel3:SetImage("icon16/cancel.png")
		end
        local Panel4 = vgui.Create( "DPanel", frame )
		Panel4:SetPos( ScrW() * 0.75, ScrH() * 0.6 )
		Panel4:SetSize( 200, 200 )
		Panel4:SetBackgroundColor(color_white)
		local icon4 = vgui.Create( "DModelPanel", frame )
		icon4:SetPos( ScrW() * 0.75, ScrH() * 0.6 )
		icon4:SetSize( 200, 200 )
		icon4:SetModel("models/outlaw/DoomEternal/DoomSlayerEternal.mdl")
		function icon4:LayoutEntity( Entity ) return end
		local button4 = vgui.Create("DButton", frame)
		button4:SetPos(ScrW()*0.86,ScrH()*0.68) 
		button4:SetText("Claim")
		button4:SetSize(75,25)
		function button4:DoClick() -- Defines what should happen when the label is clicked
			net.Start("Slayer")
			net.SendToServer(ply) 
		end
		local Panel5 = vgui.Create( "DPanel", frame )
		Panel5:SetPos( ScrW() * 0.75, ScrH() * 0.37 )
		Panel5:SetSize( 200, 200 )
		Panel5:SetBackgroundColor(color_white)
		local icon5 = vgui.Create( "DModelPanel", frame )
		icon5:SetPos( ScrW() * 0.75, ScrH() * 0.37 )
		icon5:SetSize( 200, 200 )
		icon5:SetModel("models/player/combine_super_soldier.mdl")
		function icon5.Entity:GetPlayerColor() return Vector (0, 1, 0) end
		function icon5:LayoutEntity( Entity ) return end
		local button5 = vgui.Create("DButton", frame)
		button5:SetPos(ScrW()*0.86,ScrH()*0.45) 
		button5:SetText("Claim")
		button5:SetSize(75,25)
		function button5:DoClick() -- Defines what should happen when the label is clicked
			net.Start("ttn")
			net.SendToServer(ply) 
		end
		local Panel6 = vgui.Create( "DPanel", frame )
		Panel6:SetPos( ScrW() * 0.75, ScrH() * 0.15 )
		Panel6:SetSize( 200, 200 )
		Panel6:SetBackgroundColor(color_white)
		local icon6 = vgui.Create( "DModelPanel", frame )
		icon6:SetPos( ScrW() * 0.75, ScrH() * 0.15 )
		icon6:SetSize( 200, 200 )
		icon6:SetModel("models/player/police.mdl")
		function icon6.Entity:GetPlayerColor() return Vector (0, 1, 0) end
		function icon6:LayoutEntity( Entity ) return end
		local button6 = vgui.Create("DButton", frame)
		button6:SetPos(ScrW()*0.86,ScrH()*0.25) 
		button6:SetText("Claim")
		button6:SetSize(75,25)
		function button6:DoClick() -- Defines what should happen when the label is clicked
			net.Start("gopnik")
			net.SendToServer(ply) 
		end
	end
end)

net.Receive("purchase", function (ply)
	surface.PlaySound("weapons/dmg_m4a1/cash.mp3")
end)
net.Receive("equip", function (ply)
	surface.PlaySound("npc/combine_soldier/gear3.wav")
end)

--local Panel = vgui.Create( "DPanel" )
--Panel:SetPos( ScrW() * 0.2, ScrH() * 0.2 )
--Panel:SetSize( 200, 200 )

--local icon = vgui.Create( "DModelPanel", Panel )
--icon:SetSize( 200, 200 )
--icon:SetModel( LocalPlayer():GetModel() )