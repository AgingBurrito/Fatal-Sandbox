CreateConVar( "thel_playmode_delay", "30", { FCVAR_ARCHIVE , FCVAR_SERVER_CAN_EXECUTE, FCVAR_REPLICATED } )
CreateConVar( "thel_playmode_allowspectate", "1", { FCVAR_ARCHIVE , FCVAR_SERVER_CAN_EXECUTE, FCVAR_REPLICATED } )

TLD_PLAYMODE_LANG = {}
TLD_PLAYMODE_ALLOWSPEC = GetConVar( "thel_playmode_allowspectate" ):GetInt()

function PlayMode_ChangeLang( lang )
	local lang_en = {
		class = "PlayMode",
		title = "      PlayMode Selection",
		build = "Build Mode",
		build_1 = "THIS ISNT REAL CLICK SPECTATE INSTEAD",
		pvp = "!pvp",
		pvp_1 = "FART ON PEOPLE!!!",
		cam = "!spec",
		cam_1 = "Spectate others silently.",
		noclip1 = "Allow noclip.",
		noclip2 = "Disallow noclip.",
		select = "Select",
		selected = "Selected",
	}
	local lang_cn = {
		class = "游戏模式",
		title = "      选择游戏模式",
		build = "建造模式",
		build_1 = "免疫其他玩家造成的伤害.",
		pvp = "战斗模式",
		pvp_1 = "与其他PVP玩家战斗.",
		cam = "观察模式",
		cam_1 = "暗中观察其它玩家游戏",
		noclip1 = "允许穿墙.",
		noclip2 = "无法穿墙.",
		select = "选择",
		selected = "已选择",
	}
	if lang == "zh-CN" then
		TLD_PLAYMODE_LANG = lang_cn
	else
		TLD_PLAYMODE_LANG = lang_en
	end
end
PlayMode_ChangeLang( GetConVar( "gmod_language" ):GetString() )

if SERVER then
	util.AddNetworkString( "NET_TLD_PlayMode_Menu" )
	util.AddNetworkString( "NET_TLD_PlayMode_CloseMenu" )
	util.AddNetworkString( "NET_TLD_PlayMode_Text" )
	util.AddNetworkString( "NET_TLD_PlayMode_BuildMode" )
	util.AddNetworkString( "NET_TLD_PlayMode_Refresh" )
	util.AddNetworkString( "spawnmusic" )
	
	local function TLD_PlayMode_Start( ply )
		GAMEMODE:PlayerSpawnAsSpectator( ply )
		ply:StripWeapons()
		ply:KillSilent()
		ply:Lock()
		ply:Spectate( OBS_MODE_ROAMING )
		ply:SetPos(Vector(-3273, 2935, 2042))
		ply:SetEyeAngles(Angle(27,-47,0))
		net.Start( "NET_TLD_PlayMode_Menu" )
		net.Send( ply )
	end
	
	hook.Add( "PlayerSpawnedEffect", "TLD_PlayMode_Sign", function( ply, mdl, ent )
		ent:SetNWEntity( "PlayMode_Owner", ply )
	end )
	hook.Add( "PlayerSpawnedNPC", "TLD_PlayMode_Sign", function( ply, ent )
		ent:SetNWEntity( "PlayMode_Owner", ply )
	end )
	hook.Add( "PlayerSpawnedProp", "TLD_PlayMode_Sign", function( ply, mdl, ent )
		ent:SetNWEntity( "PlayMode_Owner", ply )
	end )
	hook.Add( "PlayerSpawnedRagdoll", "TLD_PlayMode_Sign", function( ply, mdl, ent )
		ent:SetNWEntity( "PlayMode_Owner", ply )
	end )
	hook.Add( "PlayerSpawnedSENT", "TLD_PlayMode_Sign", function( ply, ent )
		ent:SetNWEntity( "PlayMode_Owner", ply )
	end )
	hook.Add( "PlayerSpawnedVehicle", "TLD_PlayMode_Sign", function( ply, ent )
		ent:SetNWEntity( "PlayMode_Owner", ply )
	end )
	
	local function TLD_SpectateAble( ent )
		return IsValid( ent ) and ent:GetNWString( "TLD_PlayMode" ) != "Unselected" and ent:GetNWString( "TLD_PlayMode" ) != "Spec"
	end
	
	hook.Add( "StartCommand", "TLD_PlayMode_Spec", function( ply, cmd )
		if ply:GetNWString( "TLD_PlayMode" ) == "Spec" and SERVER then
			if GetConVar( "thel_playmode_allowspectate" ):GetInt() <= 0 then
				TLD_PlayMode_SendText( ply, { Color( 255, 255, 255, 255 ), "Spectate mode is disabled!" } )
				ply.TLD_ModeCool = 0
				TLD_PlayMode_BuildMode( ply, "build" )
				return
			end
			if !cmd:KeyDown( IN_ATTACK ) and !cmd:KeyDown( IN_USE ) and !cmd:KeyDown( IN_ATTACK2 ) and !cmd:KeyDown( IN_JUMP ) and ply.TLD_BRSpec_Pressed then
				ply.TLD_BRSpec_Pressed = false
			end
			if #ply:GetWeapons() > 0 then
				ply:StripWeapons()
			end
			
			if ply:GetObserverMode() == OBS_MODE_CHASE then
				local tab = {}
				local num = 0
				local e = ply:GetNWEntity( "TLD_Spec_Entity" )
				
				for k, v in pairs( player.GetAll() ) do
					if IsValid( v ) and TLD_SpectateAble( v ) and !table.HasValue( tab, v ) and v != ply then
						table.insert( tab, v )
					end
				end
				if IsValid( e ) and TLD_SpectateAble( e ) then
					for k, v in pairs( tab ) do
						if v == e and num != k then num = k end
					end
				end
				
				if cmd:KeyDown( IN_ATTACK ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
						
						local n = num + 1
						if n > #tab then n = 1 end
						local nx = tab[ n ]
						
						if IsValid( nx ) and TLD_SpectateAble( e ) then
							ply:SetNWEntity( "TLD_Spec_Entity", nx )
							ply:SpectateEntity( nx )
						end
						
						num = n
					end
				end
				if cmd:KeyDown( IN_ATTACK2 ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
					
						local n = num - 1
						if n <= 0 then n = #tab end
						
						local nx = tab[ n ]
						if IsValid( nx ) and TLD_SpectateAble( nx ) then
							ply:SetNWEntity( "TLD_Spec_Entity", nx )
							ply:SpectateEntity( nx )
						end
						
						num = n
					end
				end
				
				local pre = tab[num]
				if !IsValid( pre ) or !TLD_SpectateAble( pre ) then
					local nx = tab[ num + 1 ]
					if IsValid( nx ) and TLD_SpectateAble( nx ) then
						ply:SetNWEntity( "TLD_Spec_Entity", nx )
						ply:SpectateEntity( nx )
					end
				end
				
				if cmd:KeyDown( IN_JUMP ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
						ply:Spectate( OBS_MODE_ROAMING )
						ply:SetNWBool( "TLD_Spec_Chase", false )
						if IsValid( e ) then
							ply:SetPos( e:GetPos() + e:OBBCenter() * 5 )
						end
					end
				end
				
				if ( !IsValid( e ) or !TLD_SpectateAble( e ) ) and #tab <= 0 then
					ply:Spectate( OBS_MODE_ROAMING )
					ply:SetNWBool( "TLD_Spec_Chase", false )
				end
			elseif ply:GetObserverMode() == OBS_MODE_ROAMING then
				local tab = {}
				local num = 0
				local e = ply:GetNWEntity( "TLD_Spec_Entity" )
				
				for k, v in pairs( player.GetAll() ) do
					if IsValid( v ) and TLD_SpectateAble( v ) and !table.HasValue( tab, v ) and v != ply then
						table.insert( tab, v )
					end
				end
				if IsValid( e ) and TLD_SpectateAble( e ) then
					for k, v in pairs( tab ) do
						if v == e and num != k then num = k end
					end
				end
			
				if cmd:KeyDown( IN_ATTACK ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
					
						local n = num + 1
						if n > #tab then n = 1 end
						
						local nx = tab[ n ]
						if IsValid( nx ) and TLD_SpectateAble( nx ) then
							ply:SetNWEntity( "TLD_Spec_Entity", nx )
							ply:SetPos( nx:GetPos() + nx:OBBCenter() * 3 )
						end
						
						num = n
					end
				end
				
				if cmd:KeyDown( IN_ATTACK2 ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
						
						local n = num - 1
						if n <= 0 then n = #tab end
						
						local nx = tab[ n ]
						if IsValid( nx ) and TLD_SpectateAble( nx ) then
							ply:SetNWEntity( "TLD_Spec_Entity", nx )
							ply:SetPos( nx:GetPos() + nx:OBBCenter() * 3 )
						end
						
						num = n
					end
				end
				
				local pre = tab[num]
				if !IsValid( pre ) or !TLD_SpectateAble( pre ) then
					local nx = tab[ num + 1 ]
					if IsValid( nx ) then
						ply:SetNWEntity( "TLD_Spec_Entity", nx )
					end
				end
				
				if cmd:KeyDown( IN_JUMP ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
						
						if IsValid( e ) and TLD_SpectateAble( e ) then
							ply:Spectate( OBS_MODE_IN_EYE )
							ply:SpectateEntity( e )
							ply:SetNWBool( "TLD_Spec_Chase", true )
						end
						cmd:RemoveKey( IN_JUMP )
					end
				end
			elseif ply:GetObserverMode() == OBS_MODE_IN_EYE then
				local tab = {}
				local num = 0
				local e = ply:GetNWEntity( "TLD_Spec_Entity" )
				
				for k, v in pairs( player.GetAll() ) do
					if IsValid( v ) and TLD_SpectateAble( v ) and !table.HasValue( tab, v ) and v != ply then
						table.insert( tab, v )
					end
				end
				if IsValid( e ) and TLD_SpectateAble( e ) then
					for k, v in pairs( tab ) do
						if v == e and num != k then num = k end
					end
				end
				
				if cmd:KeyDown( IN_ATTACK ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
						
						local n = num + 1
						if n > #tab then n = 1 end
						local nx = tab[ n ]
						
						if IsValid( nx ) and TLD_SpectateAble( e ) then
							ply:SetNWEntity( "TLD_Spec_Entity", nx )
							ply:SpectateEntity( nx )
						end
						
						num = n
					end
				end
				if cmd:KeyDown( IN_ATTACK2 ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
					
						local n = num - 1
						if n <= 0 then n = #tab end
						
						local nx = tab[ n ]
						if IsValid( nx ) and TLD_SpectateAble( nx ) then
							ply:SetNWEntity( "TLD_Spec_Entity", nx )
							ply:SpectateEntity( nx )
						end
						
						num = n
					end
				end
				
				local pre = tab[num]
				if !IsValid( pre ) or !TLD_SpectateAble( pre ) then
					local nx = tab[ num + 1 ]
					if IsValid( nx ) and TLD_SpectateAble( nx ) then
						ply:SetNWEntity( "TLD_Spec_Entity", nx )
						ply:SpectateEntity( nx )
					end
				end
				
				if cmd:KeyDown( IN_JUMP ) then
					if !ply.TLD_BRSpec_Pressed then
						ply.TLD_BRSpec_Pressed = true
						ply:Spectate( OBS_MODE_CHASE )
						ply:SetNWBool( "TLD_Spec_Chase", false )
						if IsValid( e ) then
							ply:SetPos( e:GetPos() + e:OBBCenter() * 5 )
						end
					end
				end
				
				if ( !IsValid( e ) or !TLD_SpectateAble( e ) ) and #tab <= 0 then
					ply:Spectate( OBS_MODE_ROAMING )
					ply:SetNWBool( "TLD_Spec_Chase", false )
				end
			end
		end
	end )
	hook.Add( "PlayerSpawn", "TLD_PlayMode_Spawn", function( ply )
		if !ply:IsBot() then
			if ply:GetNWString( "TLD_PlayMode" ) == "" then
				ply:SetNWString( "TLD_PlayMode", "Unselected" )
				TLD_PlayMode_Start( ply )
				return true
			elseif ply:GetNWString( "TLD_PlayMode" ) == "Unselected" then
				TLD_PlayMode_Start( ply )
				return true
			end
		elseif ply:GetNWString( "TLD_PlayMode" ) == "" then
			ply:SetNWString( "TLD_PlayMode", "PVP" )
		end
		if timer.Exists( "TLD_BattleRoyale_SpawnSpectate" .. ply:EntIndex() ) then
			timer.Remove( "TLD_BattleRoyale_SpawnSpectate" .. ply:EntIndex() )
		end
		if ply:GetNWString( "TLD_PlayMode" ) == "Spec" and !ply:GetNWBool( "TLD_Spec" ) then
			ply:Lock()
			ply:StripWeapons()
			local where = ply:GetPos()
			local aimto = ply:EyeAngles()
			timer.Create( "TLD_BattleRoyale_SpawnSpectate" .. ply:EntIndex(), 0.05, 1, function()
				ply:Lock()
				ply:Spawn()
				ply:KillSilent()
				ply:SetPos( where )
				ply:SetEyeAngles( Angle( aimto.pitch, aimto.yaw, 0 ) )
				ply:Spectate( OBS_MODE_ROAMING )
				
				local tab = {}
				for k, v in pairs( player.GetAll() ) do
					if IsValid( v ) and v != ply and v:Alive() then
						table.insert( tab, v )
					end
				end
				
				local ent
				if #tab > 0 then
					ent = tab[1]
					ply:Spectate( OBS_MODE_CHASE )
					ply:SpectateEntity( ent )
					ply:SetNWBool( "TLD_Spec_Chase", true )
				else
					ply:Spectate( OBS_MODE_ROAMING )
					ply:SetNWBool( "TLD_Spec_Chase", false )
				end
				
				ply:SetNWEntity( "TLD_Spec_Entity", ent )
				ply:SetNWBool( "TLD_Spec", true )
			end )
		end
	end )
	hook.Add( "PlayerSay", "TLD_PlayMode_SayCMD", function( ply, text )
		if ply:GetNWString( "TLD_PlayMode" ) == "Unselected" then
			return ""
		end
		text = string.lower( text )
		if text == "!playmode" then
			if ply.TLD_ModeCool and ply.TLD_ModeCool > CurTime() then
				TLD_PlayMode_SendText( ply, { Color( 255, 255, 255, 255 ), "You have to wait for " .. math.ceil( ply.TLD_ModeCool - CurTime() ) .. " seconds to change playmode." } )
			elseif ply.frozen then
				TLD_PlayMode_SendText( ply, { Color( 255, 255, 255, 255 ), "You are frozen." } )
			else
				net.Start( "NET_TLD_PlayMode_Menu" )
				net.Send( ply )
			end
			return ""
		elseif text == "!pvp" then
			TLD_PlayMode_BuildMode( ply, "fight" )
			return ""
		elseif text == "!spec" and GetConVar( "thel_playmode_allowspectate" ):GetInt() > 0 then
			TLD_PlayMode_BuildMode( ply, "spec" )
			return ""
		end
	end	)
	hook.Add( "EntityTakeDamage", "TLD_PlayMode_Dealt", function( target, dmg )
		if target:IsPlayer() and target:GetNWString( "TLD_PlayMode" ) != "Unselected" then
			local mode = target:GetNWString( "TLD_PlayMode" )
			local atk = dmg:GetAttacker()
			local own = atk:GetNWEntity( "PlayMode_Owner" )
			
			if mode == "Build" then
				if !( atk == target or ( IsValid( own ) and own == target ) ) then
					dmg:SetDamage( 0 )
					dmg:ScaleDamage( 0 )
				end
			end
			if mode == "PVP" then
				if ( atk:GetNWString( "TLD_PlayMode" ) == "Build" or ( IsValid( own ) and own:GetNWString( "TLD_PlayMode" ) == "Build" ) ) then
					dmg:SetDamage( 0 )
				else
					local inf = dmg:GetInflictor()
					own = inf:GetNWEntity( "PlayMode_Owner" )
					if ( IsValid( own ) and own:GetNWString( "TLD_PlayMode" ) == "Build" ) then
						dmg:SetDamage( 0 )
					end
				end
			end
		end
	end )
else
	hook.Add( "RenderScreenspaceEffects", "TLD_PlayMode_Render", function()
		local ply = LocalPlayer()
		if IsValid( ply ) and ply:GetNWString( "TLD_PlayMode" ) == "Unselected" then
			local tab = {
				["$pp_colour_addr"] = 0,
				["$pp_colour_addg"] = 0,
				["$pp_colour_addb"] = 0,
				["$pp_colour_brightness"] = 0,
				["$pp_colour_contrast"] = 1,
				["$pp_colour_colour"] = 0,
				["$pp_colour_mulr"] = 0,
				["$pp_colour_mulg"] = 0,
				["$pp_colour_mulb"] = 0
			}
			DrawColorModify( tab )
		end
	end )
	hook.Add( "HUDPaint", "TLD_PlayMode_HUD", function()
		local ply = LocalPlayer()
		if ply:GetNWString( "TLD_PlayMode" ) == "Unselected" then
			cam.Start2D()
			draw.RoundedBox( 2, 0, ScrH() * 0.85, ScrW(), ScrH() * 0.15, Color( 0, 0, 0, 200 ) )
			draw.RoundedBox( 2, 0, 0, ScrW(), ScrH() * 0.15, Color( 0, 0, 0, 200 ) )
			cam.End2D()
		else
			for k, v in pairs( player.GetAll() ) do
				-- if LocalPlayer():GetNWString("TLD_PlayMode") == "Spec" then return end
				if IsValid( v ) and v != LocalPlayer() and v:Health() > 0 and v:GetPos():DistToSqr( LocalPlayer():GetPos() ) < 500^2 and v:GetNWString( "TLD_PlayMode" ) != "Unselected" and v:GetNWString( "TLD_PlayMode" ) != LocalPlayer():GetNWString( "TLD_PlayMode" ) then
					local pos = ( v:GetPos() + v:OBBCenter() ):ToScreen()
					local alpha = ( 500^2 - v:GetPos():DistToSqr( LocalPlayer():GetPos() ) ) / 500^2 * 200
					local data = { TLD_PLAYMODE_LANG.pvp, Color( 200, 100, 100, alpha ) }
					
					if v:GetNWString( "TLD_PlayMode" ) == "Build" then
						data = { TLD_PLAYMODE_LANG.build, Color( 100, 200, 200, alpha ) }
					end
					-- draw.TextShadow( { text = data[ 1 ], pos = { pos.x, pos.y }, font = "TLD_PlayMode_Font5", color = data[ 2 ], xalign = TEXT_ALIGN_CENTER, yalign =  TEXT_ALIGN_CENTER }, 1, alpha )
				end
			end
			if ply:GetNWString( "TLD_PlayMode" ) != "Spec" or !ply:GetNWBool( "TLD_Spec_Chase" ) then
				local ent = LocalPlayer():GetEyeTrace().Entity
				if IsValid( ent ) and ent:IsPlayer() and ent:GetNWString( "TLD_PlayMode" ) != "Unselected" and ent:GetNWString( "TLD_PlayMode" ) != LocalPlayer():GetNWString( "TLD_PlayMode" ) then
					local data = { TLD_PLAYMODE_LANG.pvp, Color( 255, 100, 100, 255 ) }
					
					if ent:GetNWString( "TLD_PlayMode" ) == "Build" then
						data = { TLD_PLAYMODE_LANG.build, Color( 100, 255, 255, 255 ) }
					end
					
					local MouseX, MouseY = gui.MousePos()
					if MouseX == 0 and MouseY == 0 then
						MouseX = ScrW() / 2
						MouseY = ScrH() / 2
					end
					local x = MouseX
					local y = MouseY
					
					-- draw.Text( { text = data[ 1 ], pos = { x, y + 75 }, font = "TargetID", color = data[ 2 ], xalign = TEXT_ALIGN_CENTER, yalign =  TEXT_ALIGN_CENTER }, 1, 255 )
				end
			end
		end
		if ply:GetNWString( "TLD_PlayMode" ) == "Spec" and ply:GetNWBool( "TLD_Spec_Chase" ) and IsValid( ply:GetNWEntity( "TLD_Spec_Entity" ) ) and ply:GetNWEntity( "TLD_Spec_Entity" ):IsPlayer() then
			local specer = ply:GetNWEntity( "TLD_Spec_Entity" )
			if specer:GetNWString( "TLD_PlayMode" ) != "Unselected" and specer:GetNWString( "TLD_PlayMode" ) != "Spec" then
				local col = Color( 255, 255, 255, 255 )
				if specer:Health() <= 0 then
					col = Color( 255, 0, 0, 255 )
				end
				draw.Text( { text = specer:Nick() .. "(" .. specer:Health() .. ")", pos = { ScrW() * 512 / 1024, ScrH() * 700 / 768 }, font = "TLD_PlayMode_Font2", color = col, xalign = TEXT_ALIGN_CENTER, yalign =  TEXT_ALIGN_CENTER }, 1, 255 )
			end
		end
	end )
	
	surface.CreateFont( "TLD_PlayMode_Font1", {
		font = "Arial",
		size = 40,
		weight = 200,
		blursize = 0,
		scanlines = 1,
		antialias = true,
		shadow = true
	} )
	surface.CreateFont( "TLD_PlayMode_Font2", {
		font = "Arial",
		size = 22,
		weight = 200,
		blursize = 0,
		scanlines = 0,
		antialias = true,
		shadow = true
	} )
	surface.CreateFont( "TLD_PlayMode_Font3", {
		font = "Arial",
		size = 20,
		weight = 1000,
		blursize = 0,
		scanlines = 0,
		antialias = true,
	} )
	surface.CreateFont( "TLD_PlayMode_Font4", {
		font = "Arial",
		size = 15,
		weight = 80,
		blursize = 0,
		scanlines = 0,
		antialias = true,
		shadow = true
	} )
	surface.CreateFont( "TLD_PlayMode_Font5", {
		font = "Arial",
		size = 20,
		weight = 1000,
		blursize = 0,
		scanlines = 1,
		antialias = true
	} )
	
	local TLD_PLAYMODE_OLDLANGUAGECHANGED = LanguageChanged
	function LanguageChanged( lang )
		PlayMode_ChangeLang( lang )
		if TLD_PLAYMODE_OLDLANGUAGECHANGED then
			TLD_PLAYMODE_OLDLANGUAGECHANGED( lang )
		end
	end
end

function TLD_PlayMode_Translade( line )
	if GetConVar( "gmod_language" ):GetString() != "zh-CN" then
		return line
	end
	local line2 = {}
	for k, v in pairs( line ) do
		if isstring( v ) then
			v = string.Replace( v, "You have to wait for", "你需要再等待" )
			v = string.Replace( v, "seconds to change playmode", "秒才能更改游戏模式" )
			v = string.Replace( v, "You are frozen!", "冻结状态下无法更改游戏模式." )
			v = string.Replace( v, "You are already in this mode!", "你已经在该游戏模式下了." )
			v = string.Replace( v, "Spectate mode is disabled!", "观察模式被关闭了." )
			v = string.Replace( v, "Build", "建造模式" )
			v = string.Replace( v, "Fight", "战斗模式" )
			v = string.Replace( v, "Spectate", "观察模式" )
			v = string.Replace( v, "PlayMode Selected:", "选择模式:" )
		end
		table.insert( line2, k, v )
	end
	return line2
end
function TLD_PlayMode_SendText( ply, line )
	if SERVER then
		net.Start( "NET_TLD_PlayMode_Text" )
		net.WriteTable( line )
		net.Send( ply )
	else
		local wht = Color( 255, 255, 255, 255 )
		chat.AddText( wht, "[", Color( 255, 155, 255, 255 ), TLD_PLAYMODE_LANG.class, wht, "]", unpack( TLD_PlayMode_Translade( line ) ) )
	end
end
function TLD_PlayMode_BuildMode( ply, mode )
	local rerere = { build = "Build", fight = "PVP", spec = "Spec" }
	local what = rerere[ mode ]
	if !what then return end
	
	if SERVER then
		if ply.TLD_ModeCool and ply.TLD_ModeCool > CurTime() then
			TLD_PlayMode_SendText( ply, { Color( 255, 255, 255, 255 ), "You have to wait for " .. tostring( math.ceil( ply.TLD_ModeCool - CurTime() ) ) .. " seconds to change playmode." } )
		elseif ply.frozen then
			TLD_PlayMode_SendText( ply, { Color( 255, 255, 255, 255 ), "You are frozen." } )
		elseif ply:GetNWString( "TLD_PlayMode" ) == what then
			TLD_PlayMode_SendText( ply, { Color( 255, 255, 255, 255 ), "You are already in this mode!" } )
		else
			if what == "Build" then
				ply:SetNWString( "TLD_PlayMode", "Build" )
				TLD_PlayMode_SendText( ply, { Color( 255, 255, 255 ), "PlayMode Selected: ", Color( 100, 255, 255 ), "Build" } )
			elseif what == "PVP" then
				ply:SetNWString( "TLD_PlayMode", "PVP" )
				TLD_PlayMode_SendText( ply, { Color( 255, 255, 255 ), "PlayMode Selected: ", Color( 255, 100, 100 ), "Fight" } )
			elseif what == "Spec" then
				ply:SetNWString( "TLD_PlayMode", "Spec" )
				TLD_PlayMode_SendText( ply, { Color( 255, 255, 255 ), "PlayMode Selected: ", Color( 100, 255, 100 ), "Spectate" } )
			end
			ply:UnLock()
			ply:KillSilent()
			ply:Spawn()
			ply.TLD_ModeCool = CurTime() + math.max( GetConVar( "thel_playmode_delay" ):GetInt(), FrameTime() * 10 )
			ply:SetNWBool( "TLD_Spec", false )
			ply:SetNWBool( "TLD_Spec_Light", false )
		end
		net.Start( "NET_TLD_PlayMode_CloseMenu" )
		net.Send( ply )
	else
		net.Start( "NET_TLD_PlayMode_BuildMode" )
		net.WriteEntity( ply )
		net.WriteString( mode )
		net.SendToServer()
		
		if IsValid( LocalPlayer().Menu_TLDBuildMode ) then
			LocalPlayer().Menu_TLDBuildMode:Close()
		end
	end
end

net.Receive( "NET_TLD_PlayMode_Text", function()
	local line = net.ReadTable()
	local wht = Color( 255, 255, 255, 255 )
	chat.AddText( wht, "[", Color( 255, 155, 255, 255 ), TLD_PLAYMODE_LANG.class, wht, "]", unpack( TLD_PlayMode_Translade( line ) ) )
end )
net.Receive( "NET_TLD_PlayMode_BuildMode", function()
	local ply = net.ReadEntity()
	local mode = net.ReadString()
	TLD_PlayMode_BuildMode( ply, mode )
end )
net.Receive( "NET_TLD_PlayMode_CloseMenu", function()
	if IsValid( LocalPlayer().Menu_TLDBuildMode ) then
		LocalPlayer().Menu_TLDBuildMode:Close()
	end
end )
net.Receive( "NET_TLD_PlayMode_Refresh", function()
	if IsValid( LocalPlayer().Menu_TLDBuildMode ) then
		LocalPlayer().Menu_TLDBuildMode:RefreshIt()
	end
end )
net.Receive( "NET_TLD_PlayMode_Menu", function()
	if IsValid( LocalPlayer().Menu_TLDBuildMode ) then
		LocalPlayer().Menu_TLDBuildMode:Close()
	end
	local tx = 1
	local ty = 1
	
	local mode = LocalPlayer():GetNWString( "TLD_PlayMode" )
	
	local Frame = vgui.Create( "DFrame" )
	
	function Frame:RefreshIt()
		Frame:SetVisible( true )
		if GetConVar( "thel_playmode_allowspectate" ):GetInt() <= 0 then
			Frame:SetSize( tx * 350, ty * 200 )
		else
			Frame:SetSize( tx * 350, ty * 285 )
		end
		Frame:SetTitle( TLD_PLAYMODE_LANG.title )
		Frame:SetVisible( true )
		Frame:SetDraggable( true )
		Frame:SetDeleteOnClose( true )
		Frame:ShowCloseButton( false )
		Frame:SetScreenLock( true )
		Frame:Center()
		Frame:MakePopup()
		Frame:SetAlpha( 0 )
		Frame.RenderAlpha = CurTime()
		Frame.Paint = function( self, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 40, 40, 40, 255 ) )
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawOutlinedRect( 0, 0, w, h )
			if Frame.RenderAlpha then
				if Frame.RenderAlpha < CurTime() + 0.255 then
					Frame:SetAlpha( - ( Frame.RenderAlpha - CurTime() ) * 1000 )
				elseif Frame.RenderAlpha then
					Frame:SetAlpha( 255 )
					Frame.RenderAlpha = nil
				end
			end
		end
		Frame:SetDraggable( false )
		
		LocalPlayer().Menu_TLDBuildMode = Frame
		
		local Icon = vgui.Create( "DSprite", Frame )
		Icon:SetMaterial( Material( "icon16/brick.png" ) )
		Icon:SetPos( tx * 12, ty * 12 )
		Icon:SetSize( tx * 16, ty * 16 )
		
		if LocalPlayer():GetNWString( "TLD_PlayMode" ) != "Unselected" and LocalPlayer():GetNWString( "TLD_PlayMode" ) != "" then
			local CloseBtn = Frame:Add( "DButton" )
			CloseBtn:SetPos( tx * 300, ty * 6 )
			CloseBtn:SetSize( tx * 40, ty * 20 )
			CloseBtn:SetText( "" )
			CloseBtn.TLD_Color = Color( 89, 89, 89 )
			CloseBtn.TLD_TextColor = Color( 255, 255, 255 )
			CloseBtn.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, CloseBtn.TLD_Color )
			end
			CloseBtn.DoClick = function( self )
				surface.PlaySound( "ui/buttonclickrelease.wav" )
				Frame:Close()
			end
			CloseBtn.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, CloseBtn.TLD_Color )
				draw.Text( { text = "X", pos = { w /2, h /2 }, font = "TLD_PlayMode_Font3", color = CloseBtn.TLD_TextColor, xalign = TEXT_ALIGN_CENTER, yalign =  TEXT_ALIGN_CENTER } )
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawOutlinedRect( 0, 0, w, h )
			end
			CloseBtn.OnCursorEntered = function( self )
				surface.PlaySound( "ui/buttonrollover.wav" )
				CloseBtn.TLD_Color = Color( 100, 100, 100 )
				CloseBtn.TLD_TextColor = Color( 255, 255, 155 )
			end
			CloseBtn.OnCursorExited = function( self )
				CloseBtn.TLD_Color = Color( 89, 89, 89 )
				CloseBtn.TLD_TextColor = Color( 255, 255, 255 )
			end
		end
		
		local Pan1 = Frame:Add( "DPanel" )
		Pan1:SetSize( tx * 340, ty * 80 )
		Pan1:SetPos( tx * 5, ty * 30 )
		Pan1.Paint = function( self, w, h )		
			draw.RoundedBox( 0, 0, 0, w, h, Color( 66, 66, 66, 255 ) )
			draw.TextShadow( { text = TLD_PLAYMODE_LANG.build, pos = { tx * 15, ty * 20 }, font = "TLD_PlayMode_Font1", color = Color( 100, 100, 255 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_CENTER }, 1, 200 )
			draw.Text( { text = TLD_PLAYMODE_LANG.build_1, pos = { tx * 15, ty * 40 }, font = "TLD_PlayMode_Font4", color = Color( 255, 255, 255 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_TOP } )
			if GetConVar( "sbox_noclip" ):GetInt() > 0 then
				draw.Text( { text = TLD_PLAYMODE_LANG.noclip1, pos = { tx * 15, ty * 55 }, font = "TLD_PlayMode_Font4", color = Color( 255, 255, 255 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_TOP } )
			else
				draw.Text( { text = TLD_PLAYMODE_LANG.noclip2, pos = { tx * 15, ty * 55 }, font = "TLD_PlayMode_Font4", color = Color( 255, 255, 255 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_TOP } )		
			end
			
			surface.SetDrawColor( 30, 30, 30, 255 )
			surface.DrawOutlinedRect( 0, 0, w, h )
		end
		local Btn1 = Pan1:Add( "DButton" )
		Btn1:SetIcon( "icon16/wrench.png" )
		Btn1:SetSize( tx * 115, ty * 50 )
		Btn1:SetPos( tx * 210, ty * 15 )
		Btn1:SetText( "" )
		Btn1.TLD_Color = Color( 89, 89, 89 )
		Btn1.TLD_TextColor = Color( 255, 255, 255 )
		Btn1.Paint = function( self, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Btn1.TLD_Color )
			draw.TextShadow( { text = " " .. ( mode != "Build" and TLD_PLAYMODE_LANG.select or TLD_PLAYMODE_LANG.selected ), pos = { w / 2, h / 2 }, font = "TLD_PlayMode_Font2", color = Btn1.TLD_TextColor, xalign = TEXT_ALIGN_CENTER, yalign =  TEXT_ALIGN_CENTER }, 1, 200 )
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawOutlinedRect( 0, 0, w, h )
		end
		if mode != "Build" then
			Btn1.OnCursorEntered = function( self )
				surface.PlaySound( "ui/buttonrollover.wav" )
				Btn1.TLD_Color = Color( 100, 100, 100 )
				Btn1.TLD_TextColor = Color( 255, 255, 155 )
			end
			Btn1.OnCursorExited = function( self )
				Btn1.TLD_Color = Color( 89, 89, 89 )
				Btn1.TLD_TextColor = Color( 255, 255, 255 )
			end
			Btn1.DoClick = function()
				surface.PlaySound( "buttons/weapon_cant_buy.wav" )
			end
		else
			Btn1.TLD_Color = Color( 75, 75, 75 )
			Btn1.TLD_TextColor = Color( 200, 200, 200 )
		end
		
		local Pan2 = Frame:Add( "DPanel" )
		Pan2:SetSize( tx * 340, ty * 80 )
		Pan2:SetPos( tx * 5, ty * 115 )
		Pan2.Paint = function( self, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 66, 66, 66, 255 ) )
			draw.TextShadow( { text = TLD_PLAYMODE_LANG.pvp, pos = { tx * 15, ty * 20 }, font = "TLD_PlayMode_Font1", color = Color( 255, 100, 100 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_CENTER }, 1, 200 )
			draw.Text( { text = TLD_PLAYMODE_LANG.pvp_1, pos = { tx * 15, ty * 40 }, font = "TLD_PlayMode_Font4", color = Color( 255, 255, 255 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_TOP } )
			draw.Text( { text = TLD_PLAYMODE_LANG.noclip2, pos = { tx * 15, ty * 55 }, font = "TLD_PlayMode_Font4", color = Color( 255, 255, 255 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_TOP } )
			surface.SetDrawColor( 30, 30, 30, 255 )
			surface.DrawOutlinedRect( 0, 0, w, h )
		end
		local Btn2 = Pan2:Add( "DButton" )
		Btn2:SetIcon( "icon16/gun.png" )
		Btn2:SetSize( tx * 115, ty * 50 )
		Btn2:SetPos( tx * 210, ty * 15 )
		Btn2:SetText( "" )
		Btn2.TLD_Color = Color( 89, 89, 89 )
		Btn2.TLD_TextColor = Color( 255, 255, 255 )
		Btn2.Paint = function( self, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Btn2.TLD_Color )
			draw.TextShadow( { text = " " .. ( mode != "PVP" and TLD_PLAYMODE_LANG.select or TLD_PLAYMODE_LANG.selected ), pos = { w / 2, h / 2 }, font = "TLD_PlayMode_Font2", color = Btn2.TLD_TextColor, xalign = TEXT_ALIGN_CENTER, yalign =  TEXT_ALIGN_CENTER }, 1, 200 )
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawOutlinedRect( 0, 0, w, h )
		end
		if mode != "PVP" then
			Btn2.OnCursorEntered = function( self )
				surface.PlaySound( "ui/buttonrollover.wav" )
				Btn2.TLD_Color = Color( 100, 100, 100 )
				Btn2.TLD_TextColor = Color( 255, 255, 155 )
			end
			Btn2.OnCursorExited = function( self )
				Btn2.TLD_Color = Color( 89, 89, 89 )
				Btn2.TLD_TextColor = Color( 255, 255, 255 )
			end
			Btn2.DoClick = function()
				local ply = LocalPlayer()
				timer.Simple(0.1, function ()
					local mult = 10^(0)
			  		random = math.floor( math.Rand(1, 2)* mult + 0.5) / mult
					local moosic = GetConVar("SpawnTheme"):GetInt()
					if moosic == 0 then 
						return 
					elseif moosic == 1 then 
						ply:EmitSound("blackops".. random ..".mp3")
					elseif moosic == 2 then 
						ply:EmitSound("op40".. random ..".mp3")
					elseif moosic == 3 then 
						ply:EmitSound("rangers.mp3") 
					elseif moosic == 4 then 
						ply:EmitSound("doom.mp3")
					else 
						return  	
					end
				end)
				TLD_PlayMode_BuildMode( LocalPlayer(), "fight" )
				Frame:Close()
			end
		else
			Btn2.TLD_Color = Color( 75, 75, 75 )
			Btn2.TLD_TextColor = Color( 200, 200, 200 )
		end
		
		if GetConVar( "thel_playmode_allowspectate" ):GetInt() > 0 then
			local Pan3 = Frame:Add( "DPanel" )
			Pan3:SetSize( tx * 340, ty * 80 )
			Pan3:SetPos( tx * 5, ty * 200 )
			Pan3.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Color( 66, 66, 66, 255 ) )
				draw.TextShadow( { text = TLD_PLAYMODE_LANG.cam, pos = { tx * 15, ty * 20 }, font = "TLD_PlayMode_Font1", color = Color( 100, 255, 100 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_CENTER }, 1, 200 )
				draw.Text( { text = TLD_PLAYMODE_LANG.cam_1, pos = { tx * 15, ty * 40 }, font = "TLD_PlayMode_Font4", color = Color( 255, 255, 255 ), xalign = TEXT_ALIGN_LEFT, yalign =  TEXT_ALIGN_TOP } )
				surface.SetDrawColor( 30, 30, 30, 255 )
				surface.DrawOutlinedRect( 0, 0, w, h )
			end
			local Btn3 = Pan3:Add( "DButton" )
			Btn3:SetIcon( "icon16/camera.png" )
			Btn3:SetSize( tx * 115, ty * 50 )
			Btn3:SetPos( tx * 210, ty * 15 )
			Btn3:SetText( "" )
			Btn3.TLD_Color = Color( 89, 89, 89 )
			Btn3.TLD_TextColor = Color( 255, 255, 255 )
			Btn3.Paint = function( self, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Btn3.TLD_Color )
				draw.TextShadow( { text = " " .. ( mode != "Spec" and TLD_PLAYMODE_LANG.select or TLD_PLAYMODE_LANG.selected ), pos = { w / 2, h / 2 }, font = "TLD_PlayMode_Font2", color = Btn3.TLD_TextColor, xalign = TEXT_ALIGN_CENTER, yalign =  TEXT_ALIGN_CENTER }, 1, 200 )
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawOutlinedRect( 0, 0, w, h )
			end
			if mode != "Spec" then
				Btn3.OnCursorEntered = function( self )
					surface.PlaySound( "ui/buttonrollover.wav" )
					Btn3.TLD_Color = Color( 100, 100, 100 )
					Btn3.TLD_TextColor = Color( 255, 255, 155 )
				end
				Btn3.OnCursorExited = function( self )
					Btn3.TLD_Color = Color( 89, 89, 89 )
					Btn3.TLD_TextColor = Color( 255, 255, 255 )
				end
				Btn3.DoClick = function()
					surface.PlaySound( "ui/buttonclick.wav" )
					TLD_PlayMode_BuildMode( LocalPlayer(), "spec" )
					Frame:Close()
				end
			else
				Btn3.TLD_Color = Color( 75, 75, 75 )
				Btn3.TLD_TextColor = Color( 200, 200, 200 )
			end
		end
	end
	Frame:RefreshIt()
end )

hook.Add( "SpawnMenuOpen", "TLD_PlayMode_DisMenu1", function() if LocalPlayer():GetNWString( "TLD_PlayMode" ) == "Unselected" or LocalPlayer():GetNWString( "TLD_PlayMode" ) == "Spec" then return false end end )
hook.Add( "ContextMenuOpen", "TLD_PlayMode_DisMenu1", function() if LocalPlayer():GetNWString( "TLD_PlayMode" ) == "Unselected" or LocalPlayer():GetNWString( "TLD_PlayMode" ) == "Spec" then return false end end )
hook.Add( "PlayerNoClip", "TLD_PlayMode_DisNoclip", function( ply, bool )
	if bool then
		if ply:GetNWString( "TLD_PlayMode" ) == "Build" and GetConVar( "sbox_noclip" ):GetInt() > 0 then
			return true
		else
			return false
		end
	end
end )
hook.Add( "HUDDrawTargetID", "TLD_BR_HUDID", function()
	if LocalPlayer():GetNWString( "TLD_PlayMode" ) == "Spec" then
		if LocalPlayer():GetNWBool( "TLD_Spec_Chase" ) and IsValid( LocalPlayer():GetNWEntity( "TLD_Spec_Entity" ) ) and LocalPlayer():GetNWEntity( "TLD_Spec_Entity" ):IsPlayer() and LocalPlayer():GetNWEntity( "TLD_Spec_Entity" ):GetNWString( "TLD_PlayMode" ) != "Spec" and LocalPlayer():GetNWEntity( "TLD_Spec_Entity" ):GetNWString( "TLD_PlayMode" ) != "Unselected" then
			return true
		end
	end
end )
hook.Add( "PlayerButtonDown", "TLD_PlayMode_KP", function( ply, button )
	if CLIENT then
		if IsFirstTimePredicted() and ply:GetNWString( "TLD_PlayMode" ) == "Spec" then
			if input.GetKeyName( button ) == "f" then
				local b = ply:GetNWBool( "TLD_Spec_Light" )
				surface.PlaySound( "items/flashlight1.wav" )
				ply:SetNWBool( "TLD_Spec_Light", !b )
			end
		end
	end
end )
hook.Add( "Think", "TLD_PlayMode_Light", function()
	if !SERVER then
		local ply = LocalPlayer()
		if ply:GetNWString( "TLD_PlayMode" ) == "Spec" and ply:GetNWBool( "TLD_Spec_Light" ) then		
			local dlight = DynamicLight( ply:EntIndex() )
			if dlight then
				local tr = util.TraceLine( {
					start = ply:EyePos(),
					endpos = ply:EyePos() + ply:EyeAngles():Forward() * 256,
					filter = { ply, ply:GetNWEntity( "TLD_Spec_Entity" ) }
				} )
			
				dlight.Pos = tr.HitPos + tr.HitNormal
				
				dlight.r = 125
				dlight.g = 125
				dlight.b = 125
				dlight.Brightness = 1
				dlight.Size = 1024
				dlight.Decay = 1
				dlight.DieTime = CurTime() + 1
			end
		end
	else
		if TLD_PLAYMODE_ALLOWSPEC != GetConVar( "thel_playmode_allowspectate" ):GetInt() then
			net.Start( "NET_TLD_PlayMode_Refresh" )
			net.Broadcast()
			TLD_PLAYMODE_ALLOWSPEC = GetConVar( "thel_playmode_allowspectate" ):GetInt()
		end
	end
end )