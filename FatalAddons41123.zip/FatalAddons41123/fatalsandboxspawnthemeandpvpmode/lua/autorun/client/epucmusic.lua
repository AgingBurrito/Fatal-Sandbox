CreateClientConVar("SpawnTheme", 2, true, false, "the music that plays when u join", 0, 4)

local function playmusic()
	local ply = LocalPlayer()
	timer.Simple(0.1, function ()
		local mult = 10^(0)
  		random = math.floor( math.Rand(1, 2)* mult + 0.5) / mult
		local moosic = GetConVar("SpawnTheme"):GetInt()
		if moosic == 0 then 
			return 
		elseif moosic == 1 then 
			ply:EmitSound("blackops".. random ..".mp3")
		elseif moosic == 2 then 
			ply:EmitSound("op40".. random ..".mp3")
		elseif moosic == 3 then 
			ply:EmitSound("rangers.mp3") 
		elseif moosic == 4 then 
			ply:EmitSound("doom.mp3")
		else 
			return  	
		end
	end)
end

concommand.Add("playspawn", playmusic)


hook.Add( "AddToolMenuCategories", "music", function()
	spawnmenu.AddToolCategory( "Options", "Fatal Sandbox", "#Fatal Sandbox" )
end )

hook.Add( "PopulateToolMenu", "music", function()
	spawnmenu.AddToolMenuOption( "Options", "Fatal Sandbox", "Music", "#Music", "", "", function( panel )
		panel:ClearControls()
		panel:Button("None", "SpawnTheme", 0)
		panel:Button("Black Ops", "SpawnTheme", 1)
		panel:Button("OP 40", "SpawnTheme", 2)
		panel:Button("Rangers", "SpawnTheme", 3)
		panel:Button("DOOM", "SpawnTheme", 4)
		panel:Button("Preview", "playspawn")
	end )
end )

net.Receive("spawnmusic", playmusic)