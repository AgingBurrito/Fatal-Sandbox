if file.Exists("duelarenas", "DATA") == false then 
	file.CreateDir("dualarenas")
end
if file.Exists("dualarenas/"..game.GetMap(), "DATA") == false then 
	file.CreateDir("dualarenas/"..game.GetMap())
end

local blackroom = {
	Vector(-4779.599121, -1226.969971, -76.468948),
	Vector(-4804.676270, -1550.821289, -75.238449),
	Vector(-4742.470215, -1841.985229, -76.468948),
	Vector(-5041.897461, -2327.288330, -76.651016),
	Vector(-4385.202637, -2069.753174, -76.476700),
	Vector(-4234.631348, -1672.300171, -76.590408),
	Vector(-4077.471680, -1444.635010, -76.557892),
	Vector(-4016.947510, -1217.965210, -76.515869),
	Vector(-3422.361572, -1174.434692, -76.610443),
	Vector(-3694.703369, -1553.291748, -76.551651),
	Vector(-3453.040527, -1857.547485, -76.563660),
	Vector(-3510.759521, -2277.524658, -76.624313),
	Vector(-3385.928223, -2475.339600, -76.535202),
	Vector(-4124.898926, -2350.473389, -76.535248),
	Vector(-3952.900879, -1827.271484, -76.582642),
}
local function duelspawn(ply)
	ply:SetPos(table.Random(blackroom))
end

local function findPlayer(partOfNick)
  for _, v in ipairs(player.GetAll()) do
    if v:Nick():lower():find(partOfNick:lower()) then return v end
  end
end

util.AddNetworkString("duelrequest")

hook.Add("PlayerSay", "duelcheck", function (ply,text)
	local args = string.Split(text, " ")
	if args[1] == "!duel" then 
	    if game.GetMap() != "gm_construct" then 
	        ply:PrintMessage(HUD_PRINTTALK, "sorry bro this aint construct")
	        return 
	    end
	    if findPlayer(args[2]) == nil then 
	        ply:PrintMessage(HUD_PRINTTALK, "WHO DO YOU WANT TO DUEL??????")
	        return
	    end
		local target = findPlayer(args[2])
		if target:GetNWInt("dueling") == true then  
	        ply:PrintMessage(HUD_PRINTTALK, "HE'S ALREADY DUELING!")
	        return
	    end
		net.Start("duelrequest")
			net.WriteString(ply:Nick())
		net.Send(target)
	end
end)
util.AddNetworkString("duelacceptedclient")
util.AddNetworkString("duelacceptedserver")
util.AddNetworkString("duelstarted")
net.Receive("duelacceptedserver", function (len, ply)
	local name = net.ReadString()
	local original = findPlayer(name)
	timer.Create("dueltimer", 600, 0, function ()
	    if original:GetNWInt("duelkills") > ply:GetNWInt("duelkills") then 
	        victor = original
	   else
	       victor = ply
	       timer.Simple(3, function()
                ply:UnLock()
                original:UnLock()
           end)
	   end
		ply:Lock()
		original:Lock()
		original:PrintMessage(HUD_PRINTTALK, victor:Nick().."won the duel with "..victor:GetNWInt("duelkills"))
		ply:PrintMessage(HUD_PRINTTALK, victor:Nick().."won the duel with "..victor:GetNWInt("duelkills"))
		original:SetNWInt("duelkills", 0)
		ply:SetNWInt("duelkills", 0)
	end)
	original:PrintMessage(HUD_PRINTTALK, "YOUR DUEL GOT ACCEPTED!")
	original:SetNWInt("dueling", true)
	ply:SetNWInt("dueling", true)
	timer.Simple(3, function()
	    original:Lock()
	    duelspawn(original)
	    original:SetVelocity(-original:GetVelocity())
	    ply:Lock()
	    ply:SetVelocity(-ply:GetVelocity())
	    duelspawn(ply)
	    net.Start("duelstarted")
	    net.Send(original)
	    net.Start("duelstarted")
	    net.Send(ply)
	    timer.Simple(5, function()
            original:UnLock()
            ply:UnLock()
        end)
    end)
end)
util.AddNetworkString("dueldeniedclient")
util.AddNetworkString("dueldeniedserver")
net.Receive("dueldeniedserver", function (ply)
	local name = net.ReadString()
	local original = findPlayer(name)
	original:PrintMessage(HUD_PRINTTALK, "THAT FAGGOT DENIED YOUR DUEL REQUEST!")
end)

hook.Add("PlayerSpawn", "duel respawn", function(ply)
    if ply:GetNWInt("dueling") == true then 
        duelspawn(ply)
    end
end)

hook.Add("PlayerSay", "quitcheck", function (ply,text)
    if text == "!quit" then 
        ply:SetNWInt("dueling", false)
        print(ply:Nick().." quit a duel")
        ply:Kill()
    end
end)

hook.Add("PlayerDeath", "duel ender", function(victim, inflictor, attacker)
    if attacker:GetNWInt("duelkills") == 50 then 
        timer.Remove("dueltimer")
    end
end)