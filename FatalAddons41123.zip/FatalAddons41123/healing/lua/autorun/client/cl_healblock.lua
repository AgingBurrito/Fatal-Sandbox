local drawtext = false

net.Receive("healblock", function()
	local bool = net.ReadBool()
	drawtext = bool
end)

hook.Add("HUDPaint", "a", function()
	if drawtext then
		draw.SimpleText("Heal-Blocked", "Trebuchet24", 30, ScrH(), Color(208, 52, 44, 255), 0, 4)
	else
		draw.SimpleText("Heal-Blocked", "Trebuchet24", 30, ScrH(), Color(208, 52, 44, 0), 0, 4)
	end
end)