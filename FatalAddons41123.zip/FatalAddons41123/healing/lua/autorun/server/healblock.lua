-- AddCSLuaFile("/autorun/client/cl_healblock.lua")
-- CreateConVar("healblock_time", "3", FCVAR_ARCHIVE, "Time picking up heal items should be block after combat (in seconds, 0 for block until player dies)", 0, 300)
-- local healblock_items = {"item_healthkit", "item_healthvial", "item_battery", "item_suit"}

-- util.AddNetworkString("healblock")
-- local function healblock_netdraw(ply, bool)
-- 	net.Start("healblock")
-- 	net.WriteBool(bool)
-- 	net.Send(ply)
-- end

-- cvars.AddChangeCallback("healblock_time", function() 
-- 	for _, i in ipairs(player.GetAll()) do
-- 		if i:IsPlayer() and i:GetNWBool("healblocked") then
-- 			i:SetNWBool("healblocked", false)
-- 			timer.Remove("healblocked"..i:SteamID())
-- 		end
-- 	end
-- end)


-- hook.Add("EntityTakeDamage", "healblock_damage", function(target, dmg) 
-- 	local convartime = GetConVar("healblock_time"):GetFloat()
-- 	local attacker = dmg:GetAttacker() 
-- 	if attacker:IsPlayer() and target:IsPlayer() then 
-- 		if not attacker:GetNWBool("healblocked") then
-- 			healblock_netdraw(attacker, true)
-- 			attacker:SetNWBool("healblocked", true)
-- 		end

-- 		if not target:GetNWBool("healblocked") then
-- 			healblock_netdraw(attacker, true)
-- 			target:SetNWBool("healblocked", true)
-- 		end

-- 		if convartime > 0 then
-- 			timer.Create("healblock"..attacker:SteamID(), convartime, 1, function() 
-- 				healblock_netdraw(attacker, false)
-- 				attacker:SetNWBool("healblocked", false)
-- 			end)

-- 			timer.Create("healblock"..target:SteamID(), convartime, 1, function() 
-- 				healblock_netdraw(target, false)
-- 				target:SetNWBool("healblocked", false)
-- 			end)
-- 		end
-- 	end
-- end)

-- hook.Add("PlayerCanPickupItem", "healblock_pickup", function(ply, item) 
-- 	if ply:GetNWBool("healblocked") then 
-- 		local class = item:GetClass() 
-- 		for _, i in ipairs(healblock_items) do
-- 			if class == i then 
-- 				return false 
-- 			end
-- 		end
-- 		return true 
-- 	else 
-- 		return true
-- 	end

-- end)

-- hook.Add("PlayerDeath", "healblock_death", function(ply, _, _) 
-- 	if ply:GetNWBool("healblocked") then
-- 		healblock_netdraw(ply, false)
-- 		ply:SetNWBool("healblocked", false)
-- 	end
-- end)