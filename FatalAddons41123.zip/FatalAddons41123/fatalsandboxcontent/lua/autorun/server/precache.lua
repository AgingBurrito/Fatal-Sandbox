util.PrecacheSound("bus.mp3")
print("precached")