CreateConVar("onhitstuff", 1, FCVAR_NONE, "the heal and ammo refil on hit", 0, 1)

hook.Add("PostEntityTakeDamage", "on hit stuff", function (ent, dmg, took)
    if GetConVar("onhitstuff"):GetInt() == 0 then return end
    local atkr = dmg:GetAttacker()
    if not IsValid(ent) or not ent:IsPlayer() or atkr == ent or not IsValid(atkr) then return end
    if (atkr:Health() + dmg:GetDamage()) >= atkr:GetMaxHealth() then 
        atkr:SetArmor(math.Clamp(atkr:Armor() + atkr:Health() + dmg:GetDamage() - atkr:GetMaxHealth(), 0, atkr:GetMaxArmor()))
        atkr:SetHealth(atkr:GetMaxHealth())
    else
        atkr:SetHealth(math.Clamp(atkr:Health() + dmg:GetDamage(), 0, atkr:GetMaxHealth()))
    end
    atkr:GetActiveWeapon():SetClip1(math.Clamp(atkr:GetActiveWeapon():Clip1() + 1, 0, atkr:GetActiveWeapon():GetMaxClip1()))
    
end)