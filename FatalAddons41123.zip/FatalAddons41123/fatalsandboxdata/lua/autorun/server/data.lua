hook.Add("PlayerInitialSpawn", "data maker", function(ply)
	if ply:GetPData("playerKills") == nil then 
		ply:SetPData("playerKills", 0)
	else
		ply:SetNWInt("playerKills", ply:GetPData("playerKills"))
	end
	if ply:GetPData("playerDeaths") == nil then 
		ply:SetPData("playerDeaths", 0)
	else
		ply:SetNWInt("playerDeaths", ply:GetPData("playerDeaths"))
	end
	if ply:GetPData("playermodel") == nil then 
	    ply:SetPData("playermodel", "models/player/corpse1.mdl")
    elseif ply:GetPData("playermodel") == "models/player/tfa_superhot.mdl" then 
        ply:SetPData("playermodel", "models/player/corpse1.mdl")
    else
        ply:SetNWInt("playermodel", ply:GetPData("playermodel"))
    end
	if ply:GetPData("playerCash") == nil then 
		ply:SetPData("playerCash", 0)
	else
		ply:SetNWInt("playerCash", ply:GetPData("playerCash"))
	end
	if ply:GetPData("playerDaedric") == nil then 
		ply:SetPData("playerDaedric", 0)
	else
		ply:SetNWInt("playerDaedric", ply:GetPData("playerDaedric"))
	end
	if ply:GetPData("playerNCR") == nil then 
		ply:SetPData("playerNCR", 0)
	else
		ply:SetNWInt("playerNCR", ply:GetPData("playerNCR"))
	end
	if ply:GetPData("playerSlayer") == nil then 
		ply:SetPData("playerSlayer", 0)
	else
		ply:SetNWInt("playerSlayer", ply:GetPData("playerSlayer"))
	end
end)

util.AddNetworkString("killmoney")
hook.Add("PlayerDeath", "kill tracker", function(victim, inflictor, attacker)
	if attacker != NPC then  	
		if victim != attacker then
		    if attacker:GetNWInt("dueling") == true then 
		        attacker:SetNWInt("duelkills", attacker:GetNWInt("duelkills") + 1)
		    end
		    if attacker:IsPlayer() == false then return end 
		    victim:SetNWInt("playerDeaths", victim:GetNWInt("playerDeaths")+ 1)
		    victim:SetPData("playerDeaths", victim:GetNWInt("playerDeaths"))
		    if IsValid(attacker:GetActiveWeapon()) then 
		   		attacker:GetActiveWeapon():SetClip1(attacker:GetActiveWeapon():GetMaxClip1() + 1)
		   	end
		   	if victim:IsPlayer() == false then return end
			attacker:SetNWInt("playerKills", attacker:GetNWInt("playerKills")+ 1)
			attacker:SetPData("playerKills", attacker:GetNWInt("playerKills"))
			if victim:LastHitGroup() == 1 then 
			    attacker:SetNWInt("playerCash", attacker:GetNWInt("playerCash") + 150)
			    attacker:SetPData("playerCash", attacker:GetNWInt("playerCash"))  
		    else
			    attacker:SetNWInt("playerCash", attacker:GetNWInt("playerCash") + 100)
			    attacker:SetPData("playerCash", attacker:GetNWInt("playerCash"))
			end
			attacker:SetNWInt("playerStreak", attacker:GetNWInt("playerStreak") + 1)
			local guns = attacker:GetWeapons()
			timer.Simple(0.01, function()
		    	for k, v in pairs(guns) do
		    	    if !IsValid(v) then continue end
		            if v:GetMaxClip1() != 0 then 
			        	v:SetClip1(v:GetMaxClip1())
		        	end
	            end
	        end)
			if attacker:Alive() == true then 
                attacker:SetHealth(100)
                attacker:SetArmor(100)
				timer.Simple(0.1, function()
					if attacker:GetNWInt("playerStreak") == 25 then 
						attacker:Give("m9k_orbital_strike")
						attacker:EmitSound( "readyforlaunch.mp3" )
					end
				end)
		    end
		end
    end
    victim:SetNWInt("playerStreak", 0)
    
end)

hook.Add("PlayerInitialSpawn", "Discord message", function (ply)
     ply:PrintMessage(HUD_PRINTTALK, "https://discord.com/invite/QAAFJuGXZ3")
end)

print("data file has been run")