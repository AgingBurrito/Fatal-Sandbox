include("shared.lua")
surface.CreateFont( "TheDefaultSettings", {
    font = "Arial", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
    extended = false,
    size = 100,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
} )
surface.CreateFont( "TheDefaultSettings2", {
    font = "Arial", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
    extended = false,
    size = 50,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
} )

surface.CreateFont( "TheDefaultSettings3", {
    font = "Arial", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
    extended = false,
    size = 35,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
} )
    local frame = vgui.Create( "AvatarImage")
    frame:SetSize( 500, 500 )
    frame:SetPos(-250, -250)
    frame:SetSteamID("76561198032599112", 184)
    frame:SetPaintedManually(true)
function ENT:Draw()
    steamworks.RequestPlayerInfo("76561198032599112", function( steamName ) 
        king = steamName
    end)
    -- player = LocalPlayer()
    -- cam.Start3D2D(eyePos + (forward * 250), Angle(0, forwardAngle.y - 90, forwardAngle.r + 90), 0.2)
    cam.Start3D2D(self:GetPos(), self:GetAngles(), 0.1)
        draw.RoundedBox(0,-750,-500,1500,1000,Color(0,0,0,255))
        draw.SimpleText("THE KING OF FATAL SANDBOX", "TheDefaultSettings", 0, -400, Color(255,255,255,255), 1,1)
        draw.SimpleText(king, "TheDefaultSettings", 0, 400, Color(255,255,255,255), 1,1)
        draw.DrawText("want to be king?", "TheDefaultSettings2", -500, 0, Color( 255, 255, 255, 255 ), 1 )
        draw.DrawText("join the discord", "TheDefaultSettings2", -500, 50, Color( 255, 255, 255, 255 ), 1 )
        draw.DrawText("and challenge them", "TheDefaultSettings2", -500, 100, Color( 255, 255, 255, 255 ), 1 )
        draw.DrawText("https://discord.gg/QAAFJuGXZ3", "TheDefaultSettings3", -500, 200, Color( 255, 255, 255, 255 ), 1 )
        frame:PaintManual()
    cam.End3D2D()
end
-- local Panel = vgui.Create( "DFrame" )
 -- Panel:SetPos( 200, 200 )
 -- Panel:SetSize( 500, 500 )
 -- Panel:SetTitle( "Avatar Test" )
    
 -- local Avatar = vgui.Create( "AvatarImage", Panel )
 -- Avatar:SetSize( 64, 64 )
  -- Avatar:SetPos( 4, 30 )
 -- Avatar:SetPlayer( LocalPlayer(), 64 )
--     local Avatar = vgui.Create( "AvatarImage")
--     Avatar:SetSize( 64, 64 )
--     Avatar:SetPos( 0, 0 )
--     Avatar:SetPlayer( LocalPlayer(), 64 )
--     Avatar:SetPaintedManually(true)