CreateClientConVar("hx", 0.49, true, false, "where on the x axis the health appears", 0, 1)
CreateClientConVar("hy", 0.52, true, false, "where on the y axis the health appears", 0, 1)
CreateClientConVar("ax", 0.51, true, false, "where on the x axis the armor appears", 0, 1)
CreateClientConVar("ay", 0.52, true, false, "where on the y axis the armor appears", 0, 1)
CreateClientConVar("cx", 0.50, true, false, "where on the x axis the clip appears", 0, 1)
CreateClientConVar("cy", 0.54, true, false, "where on the y axis the clip appears", 0, 1)
CreateClientConVar("sx", 0.50, true, false, "where on the x axis the speedometer appears", 0, 1)
CreateClientConVar("sy", 0.56, true, false, "where on the y axis the speedometer appears", 0, 1)
CreateClientConVar("hp", 1, true, false, "does the health appear", 0, 1)
CreateClientConVar("ap", 1, true, false, "does the armor appear", 0, 1)
CreateClientConVar("ca", 1, true, false, "does the clip appear", 0, 1)
CreateClientConVar("sp", 1, true, false, "does the speedometer appear", 0, 1)
CreateClientConVar("sph", 1, true, false, "is the speedometer horizontal only", 0, 1)
CreateClientConVar("st", 1, true, false, "do the stats appear", 0, 1)

hook.Add( "AddToolMenuCategories", "hud", function()
	spawnmenu.AddToolCategory( "Options", "Fatal Sandbox", "#Fatal Sandbox" )
end )

hook.Add( "PopulateToolMenu", "hud", function()
	spawnmenu.AddToolMenuOption( "Options", "Fatal Sandbox", "Hud", "#Hud", "", "", function( panel )
		panel:ClearControls()
		panel:NumSlider("Health X", "hx", 0, 1)
		panel:NumSlider("Health Y", "hy", 0, 1)
		panel:NumSlider("Armor X", "ax", 0, 1)
		panel:NumSlider("Armor Y", "ay", 0, 1)
		panel:NumSlider("Clip X", "cx", 0, 1)
		panel:NumSlider("Clip Y", "cy", 0, 1)
		panel:NumSlider("Speedometer X", "sx", 0, 1)
		panel:NumSlider("Speedometer Y", "sy", 0, 1)
		panel:CheckBox("Health", "hp")
		panel:CheckBox("Armor", "ap")
		panel:CheckBox("Clip", "ca")
		panel:CheckBox("Speedometer", "sp")
		panel:CheckBox("Speedometer Horizontal Only", "sph")
		panel:CheckBox("Stats", "st")
	end )
end )

print("HUD is working")
local white1 = Color(255,255,255,255)
local green1 = Color(0,255,0,255)
local blue1 = Color(0,0,255,255)
local red1 = Color(255,0,0,255)
local black1 = Color(0,0,0,255)
local black2 = Color(0,0,0,200)

hook.Add("HUDPaint", "fatalHUD", function()
	local health = LocalPlayer():Health()
	local armor = LocalPlayer():Armor()
	local kills = LocalPlayer():Frags()
	local deaths = LocalPlayer():Deaths()
	local w,h = ScrW(), ScrH()
	local streak = LocalPlayer():GetNWInt("playerStreak")
	if deaths == 0 then 
		kd = kills 
	else local mult = 10^(1)
  		kd = math.floor(kills / deaths * mult + 0.5) / mult
	end
    
    if GetConVar("sph"):GetFloat() == 1 then 
	    local mult = 10^(0)
  	    pv = math.floor( LocalPlayer():GetVelocity():Length2D()* mult + 0.5) / mult
  	else
  	    local mult = 10^(0)
  	    pv = math.floor( LocalPlayer():GetVelocity():Length()* mult + 0.5) / mult
  	end

	
	if GetConVar("st"):GetInt() == 1 then 
		draw.RoundedBox(0, 0, 0, 125, 150, black2)
		draw.SimpleText("Kills:" .. kills .. "", "TargetID", 5, 25, white1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Deaths:" .. deaths .. "", "TargetID", 5, 50, white1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("KD:" .. kd .. "", "TargetID", 5, 75, white1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Killstreak:" .. streak .. "", "TargetID", 5, 100, whtie1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	if GetConVar("hp"):GetInt() == 1 then 
		draw.SimpleTextOutlined(health, "TargetID", ScrW() * GetConVar("hx"):GetFloat(), ScrH() * GetConVar("hy"):GetFloat(), red1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0.5, black1)
	end
	if GetConVar("ap"):GetInt() == 1 then 
		draw.SimpleTextOutlined(armor, "TargetID", ScrW() * GetConVar("ax"):GetFloat(), ScrH() * GetConVar("ay"):GetFloat(), blue1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0.5, black1)
	end
	if GetConVar("sp"):GetInt() == 1 then 
		draw.SimpleTextOutlined(pv, "TargetID", ScrW() * GetConVar("sx"):GetFloat(), ScrH() * GetConVar("sy"):GetFloat() , green1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0.5, black1)
	end
	if LocalPlayer():GetActiveWeapon() == NULL then
		return 
	elseif GetConVar("ca"):GetInt() == 1 and LocalPlayer():GetActiveWeapon():Clip1() >= 0 then
		local clip = LocalPlayer():GetActiveWeapon():Clip1()
		draw.SimpleTextOutlined(clip, "TargetID", ScrW() * GetConVar("cx"):GetFloat() , ScrH() * GetConVar("cy"):GetFloat(), green1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0.5, black1)
	end
end)