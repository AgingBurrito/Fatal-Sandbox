# UTime Changelog
## v1.45 - *(00/00/00)*
* [ADD] Zombie Survival support (Thanks, iViscosity).
* [CHANGE] New gradient texture in use (Thanks, GlenAnderson).

## v1.44 - *(01/25/16)*
* [FIX] UTime cpanel attempting to build before tool menu is populated.
* [CHANGE] Player names are no longer shown to non-admins in Murder gamemode.

## v1.43 - *(05/06/15)*
* [FIX] Changes brought on by Garry-breakage (Thanks, GGG-KILLER).
* [CHANGE] Player names are no longer shown when disguiser is enabled in TTT.

## v1.42 - *(01/27/13)*
* [ADD] utime_welcome cvar to disable welcome message.
* [FIX] Regular slew of bugs introduced by Garry (MAJOR thanks TweaK!).
* [FIX] Time string calculations being incorrect (Thanks delagious).

## v1.41 - *(08/06/10)*
* [FIX] A a few bugs some people were getting preventing the GUI from showing correctly.

## v1.40 - *(05/14/10)*
* [FIX] A disconnect bug.
* [FIX] Some bugs introduced by garry's updates.

## v1.30 - *(05/16/08)*
* [ADD] Some utility functions to make getting session and total times easier.
* [FIX] A bug introduced by one of garry's updates.

## v1.20 - *(01/03/08)*
* [ADD] Client config to change colors and position of Utime HUD element, as well as the ability to disable it.

## v1.10 - *(12/25/07)*
* [CHANGE] UTime won't display with the gmod camera out

## v1.00 - *(12/22/07)*
* Initial version
