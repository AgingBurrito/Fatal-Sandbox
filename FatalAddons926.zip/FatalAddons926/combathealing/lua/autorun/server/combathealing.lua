print("combathealing.lua")
CreateConVar("Combathealtime", 5, FCVAR_NONE, "time after taking damage until you can heal", 0, 99999999)

hook.Add("PlayerSpawn", "net int maker", function(ply, transition)
    ply:SetNWInt("incombat", 0)
end)

hook.Add("EntityTakeDamage", "in combat setter", function(ent, dmg)
    if ent:IsPlayer() then 
        ent:SetNWInt("incombat", 1)
        timer.Create(ent:Nick().."combathealdelay", 5, 1, function ()
            ent:SetNWInt("incombat", 0)
        end)
    end
end)

hook.Add("PlayerSpawnSENT", "heal checker", function (ply, ent)
    if ent == "item_battery" then
        if ply:GetNWInt("incombat") == 1 then 
            return false 
        end
    elseif ent == "item_healthkit" then 
        if ply:GetNWInt("incombat") == 1 then 
            return false
        end
    elseif ent == "item_healthvial" then 
        if ply:GetNWInt("incombat") == 1 then 
            return false 
        end
    end
end)