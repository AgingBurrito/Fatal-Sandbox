nigers = {
	"76561198149740860",
	"76561198986890767",
	"76561198979866055",
	"76561198086511083",
	"76561198083986399",
	"76561198041102484",
	"76561198144109434",
	"76561197971113899",
	"76561198878507867",
	"76561198007707041",
	"76561198249858474",
	"76561198848571917",
	"76561198166845655",
	"76561198122845661",
}

hook.Add("PlayerInitialSpawn", "niger check", function (ply)
	for k, v in pairs(nigers) do 
		if v == ply:SteamID64() then 
			for k, v in ipairs( player.GetAll() ) do
   				v:PrintMessage(HUD_PRINTTALK, ply:Nick().." IS A FAGGOT AND MUST BE KILLED! TARGET THAT NIGGA!")
   				v:EmitSound("goofyahh.mp3")
			end
		end
	end
end)
print("bal")