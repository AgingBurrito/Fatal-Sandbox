local function findPlayer(partOfNick)
  for _, v in ipairs(player.GetAll()) do
    if v:Nick():lower():find(partOfNick:lower()) then return v end
  end
end

util.AddNetworkString("duelrequest")

hook.Add("PlayerSay", "duelcheck", function (ply,text)
	local args = string.Split(text, " ")
	if args[1] == "!duel" then 
	    if game.GetMap != "gm_construct_fatal" then 
	        ply:PrintMessage(HUD_PRINTTALK, "sorry bro this aint construct")
	        return 
	    end
		local target = findPlayer(args[2])
		if target:GetNWInt("dueling") == true then  
	        ply:PrintMessage(HUD_PRINTTALK, "HE'S ALREADY DUELING!")
	        return
	    end
		net.Start("duelrequest")
			net.WriteString(ply:Nick())
		net.Send(target)
	end
end)
util.AddNetworkString("duelacceptedclient")
util.AddNetworkString("duelacceptedserver")
util.AddNetworkString("duelstarted")
net.Receive("duelacceptedserver", function (len, ply)
	local name = net.ReadString()
	local original = findPlayer(name)
	timer.Create("dueltimer", 600, 0, function ()
	    if original:GetNWInt("duelkills") > ply:GetNWInt("duelkills") then 
	        victor = original
	   else
	       victor = ply
	       timer.Simple(3, function()
                ply:UnLock()
                original:UnLock()
           end)
	   end
		ply:Lock()
		original:Lock()
		original:PrintMessage(HUD_PRINTTALK, victor:Nick().."won the duel with "..victor:GetNWInt("duelkills"))
		ply:PrintMessage(HUD_PRINTTALK, victor:Nick().."won the duel with "..victor:GetNWInt("duelkills"))
		original:SetNWInt("duelkills", 0)
		ply:SetNWInt("duelkills", 0)
	end)
	original:PrintMessage(HUD_PRINTTALK, "YOUR DUEL GOT ACCEPTED!")
	original:SetNWInt("dueling", true)
	ply:SetNWInt("dueling", true)
	timer.Simple(3, function()
	    original:Lock()
	    original:SetPos(Vector(-1139.250000, -408.037903, 15667.031250))
	    original:SetEyeAngles(Angle(0.241925, 90.253365, 0.000000))
	    original:SetVelocity(-original:GetVelocity())
	    ply:Lock()
	    ply:SetVelocity(-ply:GetVelocity())
	    ply:SetPos(Vector(-1147.929443, 2348.705811, 15667.031250))
	    ply:SetEyeAngles(Angle(0.175708, -89.707306, 0.000000))
	    net.Start("duelstarted")
	    net.Send(original)
	    net.Start("duelstarted")
	    net.Send(ply)
	    timer.Simple(10, function()
            original:UnLock()
            ply:UnLock()
        end)
    end)
end)
util.AddNetworkString("dueldeniedclient")
util.AddNetworkString("dueldeniedserver")
net.Receive("dueldeniedserver", function (ply)
	local name = net.ReadString()
	local original = findPlayer(name)
	original:PrintMessage(HUD_PRINTTALK, "THAT FAGGOT DENIED YOUR DUEL REQUEST!")
end)

hook.Add("PlayerSpawn", "duel respawn", function(ply)
    if ply:GetNWInt("dueling") == true then 
        ply:SetPos(Vector(-1863.553101, 2037.798706, 15667.031250))
    end
end)

hook.Add("PlayerSay", "quitcheck", function (ply,text)
    if text == "!quit" then 
        ply:SetNWInt("dueling", false)
        print(ply:Nick().." quit a duel")
        ply:Kill()
    end
end)

hook.Add("PlayerDeath", "duel ender", function(victim, inflictor, attacker)
    if attacker:GetNWInt("duelkills") == 50 then 
        timer.Remove("dueltimer")
    end
end)