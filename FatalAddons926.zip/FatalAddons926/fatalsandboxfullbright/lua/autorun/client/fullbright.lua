CreateClientConVar("fullbright_players", "1", true, false, "makes players fullbright", 0, 1)

hook.Add( "AddToolMenuCategories", "Fullbright", function()
	spawnmenu.AddToolCategory( "Options", "Fatal Sandbox", "#Fatal Sandbox" )
end )

hook.Add( "PopulateToolMenu", "Fullbright", function()
	spawnmenu.AddToolMenuOption( "Options", "Fatal Sandbox", "Fullbright", "#Fullbright", "", "", function( panel )
		panel:ClearControls()
		panel:CheckBox("Fullbright for players", "fullbright_players")
		-- Add stuff here
	end )
end )

hook.Add( "PrePlayerDraw" , "manual_model_draw_example" , function( ply )
	local bright = GetConVar("fullbright_players"):GetInt()
	if bright == 1 then render.SuppressEngineLighting(true)
	end 
end)

hook.Add("PostPlayerDraw", "reset", function ()
	render.SuppressEngineLighting(false)
end)