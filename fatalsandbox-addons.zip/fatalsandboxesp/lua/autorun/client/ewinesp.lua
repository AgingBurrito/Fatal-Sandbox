CreateClientConVar("ESPBox", 0, true, false, "toggles the box around people", 0, 1)
CreateClientConVar("ESPName", 1, true, false, "toggles the box around people", 0, 1)

hook.Add( "AddToolMenuCategories", "CustomCategory", function()
	spawnmenu.AddToolCategory( "Options", "Fatal Sandbox", "#Fatal Sandbox" )
end )

hook.Add( "PopulateToolMenu", "CustomMenuSettings", function()
	spawnmenu.AddToolMenuOption( "Options", "Fatal Sandbox", "ESP", "#ESP", "", "", function( panel )
		panel:ClearControls()
		panel:CheckBox("ESPBox", "ESPBox")
		panel:CheckBox("ESPName", "ESPName")
		-- Add stuff here
	end )
end )

hook.Add('HUDPaint', 'AESP.Info', function()
	for k, v in pairs(player.GetAll()) do
		if v == LocalPlayer() then continue end
		if v:GetNWString( "TLD_PlayMode" ) == "Spec" then continue end
		green = Color(0,255,0,255)
		black = Color(0,0,0,255)
		local name = GetConVar("ESPName"):GetInt()
		local pos = v:GetPos() + Vector(0,0,75)
		pos = pos:ToScreen()
		if name == 1 then 
			draw.SimpleTextOutlined(v:Name(),"DermaDefault",pos.x,pos.y, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black)
		end
	end
end)

hook.Add( "PostDrawTranslucentRenderables", "Boxxie", function()
    for k, v in pairs(player.GetAll()) do 
    	if v == LocalPlayer() then continue end
    	local Box = GetConVar("ESPBox"):GetInt()
    	local pos = v:GetPos() -- position to render box at
    	render.SetColorMaterial() -- white material for easy coloring
    	cam.IgnoreZ( false ) -- makes next draw calls ignore depth and draw on top
    	if Box == 1 then
    		render.DrawWireframeBox( pos, angle_zero, Vector(-15, -15, 0), Vector(15, 15, 75)	, Color(0,255,0) ) -- draws the box
    	end 
    	cam.IgnoreZ( false ) -- disables previous call
    end
end)