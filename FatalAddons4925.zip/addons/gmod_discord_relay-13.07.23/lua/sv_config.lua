Discord = {
	['webhook'] = "https://discord.com/api/webhooks/1168270291600945153/SaBc3ZyD5VHDcpt-lrUGqdAnnEwiTrpKmS9JaUd7S_O6tJMoeqbvcOkCEio-t1Dm-9vw",
	
	['hookname'] = "Fatal Relay",

	['readChannelID'] = "1168270090253373574",

	['botToken'] = 'MTE2ODI3NjIzODYzMzI5MTg2OA.GMHQ4_.4LFPCUV09d_fmuiXkKWK05VSudKG93J_A4vXVM',

	["botPrefix"] = "!",

	-- For developers (logs)
	['debug'] = false,

	-- Don't touch!
	['commands'] = {}
}