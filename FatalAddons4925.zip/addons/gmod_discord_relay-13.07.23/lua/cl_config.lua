Discord = {
	-- In CLIENT chat
	['prefix'] = "Discord",

	['prefixClr'] = Color(88, 101, 242),
}