if CLIENT then
	CreateClientConVar("q3_lightning_beam", 1, true, false, "display the beam")
end

if SERVER then

	AddCSLuaFile("shared.lua")
	
else

	SWEP.PrintName			= "Lightning Gun"			
	SWEP.Author				= "Upset"
	SWEP.Slot				= 3
	SWEP.SlotPos			= 0
	SWEP.Q3Slot				= 6
	SWEP.Q3Icon				= "vgui/q3icons/iconw_lightning"
	SWEP.WepSelectIcon		= surface.GetTextureID(SWEP.Q3Icon)
	SWEP.RenderGroup		= RENDERGROUP_BOTH
	killicon.Add("weapon_q3_lightninggun", SWEP.Q3Icon, Color(255, 255, 255, 255))
	
end

function SWEP:OnRemove()
	self:SetAttack(nil)
	self:StopHumSound()
	if self.firesound then self.firesound:Stop() end
	if IsValid(self.Owner) then self.Owner:StopSound(self.Primary.Special) end
end

function SWEP:DoTrace()
	if self.Owner:IsPlayer() then
		local tr = util.TraceLine({
			start = self.Owner:GetShootPos(),
			endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * self.HitDist,
			filter = self.Owner
		})
	
		return tr
	elseif self.Owner:IsNPC() then
		local aimvector = self:GetForward()
		if SERVER then
			aimvector = self.Owner:GetAimVector()
		end
		local tr = util.TraceHull({
			start = self:GetPos(),
			endpos = self:GetPos() + aimvector * self.HitDist,
			filter = self.Owner
		})
	
		return tr
	end
end

function SWEP:PrimaryAttack()
	if !self:CanPrimaryAttack() then return end
	
	if self.Owner:IsNPC() then
		if !self:GetAttack() then
			self:SetAttack(true)
			self:WeaponSound()
			self:EmitSound(self.Primary.Special, 100, 100, 1, CHAN_ITEM)
		end
		if self:GetAttack() then
			self:SetNextPrimaryFire(CurTime() + self:GetNextAttackDelay())
			self:MuzzleQuake()
			local tr = self:DoTrace()	
			if tr.HitWorld then
				local hit1, hit2 = tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal
			elseif IsValid(tr.Entity) then
				self:DealDamage(tr.Entity)
			end
			if tr.Hit then
				sound.Play("weapons/lightning/lg_hit"..math.random(1,3)..".wav", tr.HitPos, 80, 100)
			end
		end
		return
	end
	
	if !self:GetAttack() then
		if !self.firesound then
			self.firesound = CreateSound(self.Owner, self.Primary.Special)
			self.firesound:SetSoundLevel(90)
		end
		if self.firesound and !self.firesound:IsPlaying() then
			self.firesound:Play()
		end
		self:WeaponSound()
		self:SetAttack(true)
	end
	
	self:SetNextPrimaryFire(CurTime() + self:GetNextAttackDelay())
	self:MuzzleQuake()
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	
	if SERVER then self.Owner:LagCompensation(true) end
	local tr = self:DoTrace()
	
	if tr.HitWorld then
		local hit1, hit2 = tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal
	end

	if SERVER then 
		if tr.HitNonWorld then
			self:DealDamage(tr.Entity)
		end
		self.Owner:LagCompensation(false)
	end

	if tr.Hit and SERVER then
		sound.Play("weapons/lightning/lg_hit"..math.random(1,3)..".wav", tr.HitPos, 80, 100)
	end
end

function SWEP:DealDamage(ent)
	local dmginfo = DamageInfo()
	dmginfo:SetDamage(self.Primary.Damage)
	dmginfo:SetAttacker(self.Owner)
	dmginfo:SetInflictor(self)
	dmginfo:SetDamageType(2)
	ent:TakeDamageInfo(dmginfo)
end

function SWEP:SpecialThink()
	if self.Owner:KeyDown(IN_ATTACK) and self:WepHasAmmo() then
		if IsFirstTimePredicted() and self:GetAttack() then
			local tr = self:DoTrace()
			if tr.HitWorld or tr.HitNonWorld then
				local beameffect = EffectData()
				beameffect:SetOrigin(tr.HitPos + tr.HitNormal)
				util.Effect("q3lightning_impact", beameffect)
			end
		end
	end
	if self:GetAttack() and (!self.Owner:KeyDown(IN_ATTACK) or !self:WepHasAmmo()) then
		self:SetAttack(nil)
		if self.firesound then self.firesound:Stop() end
	end
end

local light1 = Material("sprites/lightning3new")
local lighthit = Material("sprites/q3/electric")

function SWEP:ViewModelDrawn(vm)
	if !self:GetAttack() then return end

	local bone = vm:GetAttachment(1)
	local tr = self:DoTrace()
	local ct1 = CurTime() *6
	local ct2 = CurTime() *-6
	
	local pos = bone.Pos
	local pos1 = bone.Pos + bone.Ang:Up() * 1.8
	local size = 16
	if CLIENT then
		if GetConVar("q3_lightning_beam"):GetBool() then
			render.SetMaterial(light1)
			render.DrawBeam(pos, tr.HitPos, size, ct1, ct1 -5, Color(255, 255, 255, 255))
			render.DrawBeam(pos1, tr.HitPos, size, ct2, ct2 -5, Color(255, 255, 255, 255))
		end
	end
	
	
	/*local hitpos = tr.HitPos + tr.HitNormal
	local Angle = hitpos:Angle()
	
	local F = Angle:Forward()
	local R = Angle:Right()
	local U = Angle:Up()
	
	local hsize = 50
	
	local asd = math.random(-10,10)
	local rot = math.random(-90,90)
	if tr.HitWorld or tr.HitNonWorld then
		render.SetMaterial(lighthit)
		render.DrawQuadEasy(hitpos, R + F * asd, hsize, hsize, Color(255,255,255,255), rot)
		render.DrawQuadEasy(hitpos, U + R * asd, hsize, hsize, Color(255,255,255,255), rot)
		render.DrawQuadEasy(hitpos, F + U * asd, hsize, hsize, Color(255,255,255,255), rot)
	end*/
end

function SWEP:DrawWorldModel()
	self:DrawModel()
end

function SWEP:DrawWorldModelTranslucent()
	if !self:GetAttack() then return end
	
	local bone = self:GetAttachment(1)
	local tr = self:DoTrace()
	if !tr then return end
	local ct1 = CurTime() *6
	local ct2 = CurTime() *-6
	
	local pos = bone.Ang:Right() * 2
	local size = 24
	if CLIENT then
		if GetConVar("q3_lightning_beam"):GetBool() then
			render.SetMaterial(light1)
			render.DrawBeam(bone.Pos + pos, tr.HitPos, size, ct1, ct1 -4, Color(255, 255, 255, 255))
			render.DrawBeam(bone.Pos - pos, tr.HitPos, size, ct2, ct2 -4, Color(255, 255, 255, 255))
		end
	end
	
	self:SetRenderBoundsWS(bone.Pos, tr.HitPos)
end

if SERVER then
	function SWEP:NPCShoot_Primary(ShootPos, ShootDir)
		self:PrimaryAttack()
		timer.Create("Q3LightningGun_NPCAttack"..self:EntIndex(), .08, 12, function()
			if IsValid(self) and IsValid(self.Owner) then
				local enemy = self.Owner:GetEnemy()
				if IsValid(enemy) then
					local ang = (enemy:GetPos() - ShootPos):Angle()
					self.Owner:SetIdealYawAndUpdate(ang[2])
					self:PrimaryAttack()
				end
			end
		end)
		timer.Create("Q3LightningGun_NPCAttackStop"..self:EntIndex(), 1, 1, function()
			if IsValid(self) and IsValid(self.Owner) then
				self.Owner:StopSound(self.Primary.Special)
				self:SetAttack(false)
			end
		end)
	end
	
	function SWEP:GetNPCBulletSpread()
		return 1
	end

	function SWEP:GetNPCBurstSettings()
		return 1, 1, math.Rand(1,2)
	end

	function SWEP:GetNPCRestTimes()
		return 5, 10
	end
end

SWEP.HoldType			= "ar2"
SWEP.Base				= "weapon_q3_base"
SWEP.Category			= "Quake 3"
SWEP.Spawnable			= true

SWEP.ViewModel			= "models/weapons/v_q3_lightninggun.mdl"
SWEP.WorldModel			= "models/weapons/w_q3_lightninggun.mdl"

SWEP.Primary.Sound			= Sound("weapons/lightning/lg_fire.wav")
SWEP.Primary.Special		= Sound("weapons/lightning/lg_hum.wav")
SWEP.Primary.Damage			= 2
SWEP.Primary.Delay			= 0
SWEP.Primary.Ammo			= "GaussEnergy"
SWEP.EquipAmmoAmount		= 100
SWEP.HitDist				= 768

SWEP.EnableHS				= false
SWEP.HumSnd					= Sound("weapons/melee/fsthum.wav")

SWEP.MuzzleName				= "q3mflash_lightning"
SWEP.MuzzleRight			= 10
SWEP.MuzzleUp				= -10
SWEP.MuzzleLight			= "q3muzzlelight_lightning"

SWEP.EntityPickup			= "q3_pickup_lightning"