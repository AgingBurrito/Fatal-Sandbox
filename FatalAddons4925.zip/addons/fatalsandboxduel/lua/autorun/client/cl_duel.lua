net.Receive("duelrequest", function (ply)
	local name = net.ReadString()
	local frame = vgui.Create("DFrame")
	frame:SetSize(200, 200)
	frame:SetDeleteOnClose(true)
	frame:ShowCloseButton(true)
	frame:SetPos(0, 300)
	frame:SetTitle("DUEL REQUEST")
	local label1 = vgui.Create("DButton", frame)
	label1:SetText("SLAUGHTER")
	label1:SetPos(10, 50)
	label1:SetSize(100, 50)
	local label2 = vgui.Create("DButton", frame)
	label2:SetText("DENY")
	label2:SetPos(10, 100)
	label2:SetSize(100, 50)
	function label1:DoClick() 
		LocalPlayer():EmitSound("challengeaccepted.mp3")
		print( "CHALLENGE ACCEPTED")	-- Print something when a key is pressed
		frame:Close()
		net.Start("duelacceptedserver")
			net.WriteString(name)
		net.SendToServer()
		timer.Create("dueltimer", 600, 0, function ()
			print("duels over folks!")
		end)
	end 
	function label2:DoClick()
		LocalPlayer():EmitSound("yousuck.mp3")
		print( "CHALLENGE DENIED")	-- Print something when a key is pressed
		frame:Close()
		net.Start("dueldeniedserver")
			net.WriteString(name)
		net.SendToServer() 
	end
	label3 = vgui.Create("DLabel", frame)
	label3:SetText("OPPONENT: "..name.."")
	label3:SetSize(500, 100)
	label3:SetPos(10, 115)
end)

net.Receive("dueldeniedclient", function()
print("THAT FAGGOT DENIED YOUR REQUEST!")
end)

net.Receive("duelstarted", function()
    local mult = 10^(0)
			  		random = math.floor( math.Rand(1, 2)* mult + 0.5) / mult
					local moosic = GetConVar("SpawnTheme"):GetInt()
					if moosic == 0 then 
						return 
					elseif moosic == 1 then 
						LocalPlayer():EmitSound("blackops".. random ..".mp3")
					elseif moosic == 2 then 
						LocalPlayer():EmitSound("op40".. random ..".mp3")
					elseif moosic == 3 then 
						LocalPlayer():EmitSound("rangers.mp3") 
					elseif moosic == 4 then 
						LocalPlayer():EmitSound("doom.mp3")
					else 
						return  	
					end
end)

hook.Add("HUDPaint", "duel stats", function ()
	if LocalPlayer():GetNWInt("dueling") == true then
		local white1 = Color(255,255,255,255) 
		local black2 = Color(0,0,0,200)
		draw.RoundedBox(0, 0, 150, 125, 150, black2)
		draw.SimpleText("Time: " .. string.NiceTime(timer.TimeLeft("dueltimer")) .. "", "TargetID", 5, 150, white1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.DrawText("Kills: " .. LocalPlayer():GetNWInt("duelkills"), "TargetID", 5, 160, color_white, TEXT_ALIGN_LEFT )
	end
end)