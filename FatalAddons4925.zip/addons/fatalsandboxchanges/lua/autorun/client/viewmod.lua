local flipblacklist = {
	
	[ "weapon_crowbar" ] = true,
	[ "weapon_physcannon" ] = true,
	[ "weapon_physgun" ] = true,
	[ "weapon_pistol" ] = true,
	[ "weapon_357" ] = true,
	[ "weapon_smg1" ] = true,
	[ "weapon_ar2" ] = true,
	[ "weapon_shotgun" ] = true,
	[ "weapon_crossbow" ] = true,
	[ "weapon_frag" ] = true,
	[ "weapon_rpg" ] = true,
	[ "weapon_slam" ] = true,
	[ "weapon_stunstick" ] = true,
	[ "weapon_bugbait" ] = true,
	[ "weapon_medkit" ] = true,
	
}


----
-- Console commands and variables
----

local convars = {
	
	{ "viewmod_enable", 0, "CheckBox", "Enabled" },
	{ "viewmodel_delete", 0, "CheckBox", "Delete Viewmodel"},
	{ "viewmod_thirdperson", 0, "CheckBox", "Thirdperson" },
	{ "viewmod_worldmodel", 0, "CheckBox", "Firstperson use worldmodel" },
	{ "viewmod_flip", 0, "CheckBox", "Viewmodel flip" },
	{ "viewmod_useweppos", 1, "CheckBox", "Use weapon pos/ang" },
	{ "viewmod_aimzoom", 1, "CheckBox", "Zoom in when aiming with snipers"},
	{ "viewmod_zoom2", 100, "Slider", "Field of view", 0, 179 },
	{ "viewmod_fov", 90, "Slider", "Viewmodel field of view", 0, 179 },
	{ "viewmod_bob", 1, "Slider", "Bob scale", -10, 10 },
	{ "viewmod_sway", 1, "Slider", "Sway scale", -25, 25 },
	{ "viewmod_x", 0, "Slider", "Left/right offset", -15, 15 },
	{ "viewmod_y", 0, "Slider", "Backward/forward offset", -15, 15 },
	{ "viewmod_z", 0, "Slider", "Down/up offset", -15, 15 },
	{ "viewmod_pitch", 0, "Slider", "Pitch offset", -180, 180 },
	{ "viewmod_yaw", 0, "Slider", "Yaw offset", -180, 180 },
	{ "viewmod_roll", 0, "Slider", "Roll offset", -180, 180 },
	{ "viewmod_tpy", 60, "Slider", "Thirdperson distance", 25, 100 },
	{ "viewmod_tpx", 40, "Slider", "Thirdperson left/right offset", -100, 100 },
	{ "viewmod_tpz", 0, "Slider", "Thirdperson down/up offset", -100, 100 },
	{ "viewmod_oldtpaim", 1, "CheckBox", "Old thirdperson aiming" },
	
}

local created = {}
local clamps = {}
for i = 1, #convars do
	
	created[ convars[ i ][ 1 ] ] = CreateClientConVar( convars[ i ][ 1 ], convars[ i ][ 2 ], true, false )
	clamps[ convars[ i ][ 1 ] ] = { convars[ i ][ 5 ], convars[ i ][ 6 ] }
	
end

local function clampfloat( name )
	
	return math.Clamp( created[ name ]:GetFloat(), clamps[ name ][ 1 ], clamps[ name ][ 2 ] )
	
end

concommand.Add( "viewmod_reset", function()
	
	for i = 1, #convars do
		
		if convars[ i ][ 3 ] ~= "CheckBox" then
			
			RunConsoleCommand( convars[ i ][ 1 ], convars[ i ][ 2 ] )
			
		end
		
	end
	
end )

concommand.Add( "viewmod_print", function()
	
	for i = 1, #convars do
		
		if i == 1 then
			
			Msg( "\n" )
			
		else
			
			Msg( ";" )
			
		end
		
		if convars[ i ][ 3 ] == "CheckBox" then
			
			Msg( convars[ i ][ 1 ], " ", created[ convars[ i ][ 1 ] ]:GetInt() )
			
		elseif convars[ i ][ 3 ] == "Slider" then
			
			Msg( convars[ i ][ 1 ], " ", math.Round( created[ convars[ i ][ 1 ] ]:GetFloat(), 2 ) )
			
		end
		
		if i == #convars then Msg( "\n" ) end
		
	end
	
end )

local cheats = GetConVar( "sv_cheats" )


----
-- Viewmodel flipping
----

local vmflip = {}

local function ViewModelFlip( weapon )
	
	if IsValid( weapon ) == false then return end
	
	if weapon:IsScripted() == true and flipblacklist[ weapon:GetClass() ] ~= true then
		
		if vmflip[ weapon ] == nil then vmflip[ weapon ] = weapon.ViewModelFlip end
		
		if created[ "viewmod_enable" ]:GetBool() == true and created[ "viewmod_flip" ]:GetBool() == true then
			
			weapon.ViewModelFlip = ( vmflip[ weapon ] or false ) == false
			
		else
			
			weapon.ViewModelFlip = vmflip[ weapon ]
			
		end
		
	end
	
end


----
-- Viewmodel field of view
----

local vmfov = {}

local function ViewModelFOV( weapon, value )
	
	if IsValid( weapon ) == false then return end
	
	if vmfov[ weapon ] == nil then vmfov[ weapon ] = weapon.ViewModelFOV or 62 end
	
	if created[ "viewmod_enable" ]:GetBool() == true then
		
		if value ~= nil then
			
			weapon.ViewModelFOV = value
			if cheats:GetBool() == true then RunConsoleCommand( "viewmodel_fov", value ) end
			
		else
			
			weapon.ViewModelFOV = created[ "viewmod_fov" ]:GetFloat()
			if cheats:GetBool() == true then RunConsoleCommand( "viewmodel_fov", created[ "viewmod_fov" ]:GetFloat() ) end
			
		end
		
	else
		
		weapon.ViewModelFOV = vmfov[ weapon ]
		
	end
	
end


----
-- Viewmodel bobbing
----

local vmbob = {}

local function ViewModelBob( weapon, value )
	
	if IsValid( weapon ) == false then return end
	
	if vmbob[ weapon ] == nil then vmbob[ weapon ] = weapon.BobScale or 1 end
	
	if created[ "viewmod_enable" ]:GetBool() == true then
		
		value = value or created[ "viewmod_bob" ]:GetFloat()
		
		weapon.BobScale = vmbob[ weapon ] * value
		
	else
		
		weapon.BobScale = vmbob[ weapon ]
		
	end
	
end


----
-- Viewmodel swaying
----

local vmsway = {}

local function ViewModelSway( weapon, value )
	
	if IsValid( weapon ) == false then return end
	
	if vmsway[ weapon ] == nil then vmsway[ weapon ] = weapon.SwayScale or 1 end
	
	if created[ "viewmod_enable" ]:GetBool() == true then
		
		value = value or created[ "viewmod_sway" ]:GetFloat()
		
		weapon.SwayScale = vmsway[ weapon ] * value
		
	else
		
		weapon.SwayScale = vmsway[ weapon ]
		
	end
	
end


----
-- Viewmodel offset
----

local x = created[ "viewmod_x" ]:GetFloat()
local y = created[ "viewmod_y" ]:GetFloat()
local z = created[ "viewmod_z" ]:GetFloat()
local pitch = created[ "viewmod_pitch" ]:GetFloat()
local yaw = created[ "viewmod_yaw" ]:GetFloat()
local roll = created[ "viewmod_roll" ]:GetFloat()

local function ViewModelOffset( weapon, x_, y_, z_, pitch_, yaw_, roll_ )
	
	if IsValid( weapon ) == false then return end
	
	if x_ == nil then x = created[ "viewmod_x" ]:GetFloat() else x = x_ end
	if y_ == nil then y = created[ "viewmod_y" ]:GetFloat() else y = y_ end
	if z_ == nil then z = created[ "viewmod_z" ]:GetFloat() else z = z_ end
	
	if pitch_ == nil then pitch = created[ "viewmod_pitch" ]:GetFloat() else pitch = pitch_ end
	if yaw_ == nil then yaw = created[ "viewmod_yaw" ]:GetFloat() else yaw = yaw_ end
	if roll_ == nil then roll = created[ "viewmod_roll" ]:GetFloat() else roll = roll_ end
	
end

hook.Add( "CalcViewModelView", "ViewMod_CalcViewModelView", function( wep, vm, pos_, ang_, pos, ang )

	if created[ "viewmod_enable" ]:GetBool() == true then
		
		local weppos = pos
		local wepang = ang
		
		if wep.GetViewModelPosition ~= nil then
			
			local wp, wa = wep:GetViewModelPosition( pos, ang )
			if isvector( wp ) == true then weppos = wp end
			if isangle( wa ) == true then wepang = wa end
			if created[ "viewmod_useweppos" ]:GetBool() == true and ( wp ~= pos or wa ~= ang ) then return weppos, wepang end
			
		end
		
		return weppos + ( ang:Right() * x ) + ( ang:Forward() * y ) + ( ang:Up() * z ), wepang + Angle( pitch, yaw, roll )
		
	end
	
end )


----
-- Update viewmodel
----

local function ViewModUpdate( weapon )
	
	ViewModelFlip( weapon )
	ViewModelFOV( weapon )
	ViewModelBob( weapon )
	ViewModelSway( weapon )
	ViewModelOffset( weapon )
	
end

for i = 1, #convars do
	
	cvars.AddChangeCallback( convars[ i ][ 1 ], function()
		
		ViewModUpdate( LocalPlayer():GetActiveWeapon() )
		
	end, convars[ i ][ 1 ] )
	
end

hook.Add( "HUDWeaponPickedUp", "ViewMod_FlipClient", function( weapon )
	
	if created[ "viewmod_enable" ]:GetBool() == true then ViewModUpdate( weapon ) end
	
end )

hook.Add( "PlayerSwitchWeapon", "ViewMod_FlipShared", function( ply, old, new )
	
	if created[ "viewmod_enable" ]:GetBool() == true and IsFirstTimePredicted() == true then ViewModUpdate( new ) end
	
end )


----
-- Thirdperson/worldmodel camera
----

local prevpos = Vector( 0, 0, 0 )
local prevang = Angle( 0, 0, 0 )

local headscale = Vector( 1, 1, 1 )
local function scale( s )
	
	if s ~= headscale then
		
		local ply = LocalPlayer()
		local head = ply:LookupBone( "ValveBiped.Bip01_Head1" )
		if head ~= nil then
			
			headscale = s
			ply:ManipulateBoneScale( head, s )
			
		end
		
	end
	
end

hook.Add( "CalcView", "ViewMod_CalcView", function( ply, pos, ang, fov, near, far )
	if created [ "viewmod_aimzoom" ]:GetBool() == true then 
		if LocalPlayer():KeyDown(IN_ATTACK2) then return end
		if LocalPlayer():KeyDown(IN_ZOOM) then return end
	end
	prevpos = pos
	prevang = ang
	
	local head = ply:LookupBone( "ValveBiped.Bip01_Head1" )
	
	if created[ "viewmod_enable" ]:GetBool() == true and ( IsValid( ply:GetActiveWeapon() ) == false or ply:GetActiveWeapon():GetClass() ~= "gmod_camera" ) and GetViewEntity() == ply then
		
		local originpos = pos
		local angle = ang
		local zoom = created[ "viewmod_zoom2" ]:GetFloat()
		local drawply = false
		
		if created[ "viewmod_thirdperson" ]:GetBool() == true then
			
			scale( Vector( 1, 1, 1 ) )
			
			local trace = util.TraceLine( {
				
				start = pos,
				endpos = pos - ( ang:Forward() * clampfloat( "viewmod_tpy" ) ) + ( ang:Right() * clampfloat( "viewmod_tpx" ) ) + ( ang:Up() * clampfloat( "viewmod_tpz" ) ),
				filter = ply,
				
			} )
			
			originpos = trace.HitPos + ang:Forward() * 16
			
			if pos:Distance( originpos ) < 8 then
				
				drawply = false
				
			else
				
				drawply = true
				
			end
			
			if created[ "viewmod_oldtpaim" ]:GetBool() ~= true then angle = ( ply:GetEyeTraceNoCursor().HitPos - originpos ):Angle() end
			
		elseif created[ "viewmod_worldmodel" ]:GetBool() == true then
			
			if IsValid( ply:GetRagdollEntity() ) == true then
				
				ply:ManipulateBoneScale( ply:GetRagdollEntity():LookupBone( "ValveBiped.Bip01_Head1" ), Vector( 0, 0, 0 ) )
				
				originpos, angle = ply:GetRagdollEntity():GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) )
				
			elseif head ~= nil then
				
				local eyes = ply:GetAttachment( ply:LookupAttachment( "eyes" ) )
				if eyes ~= nil and eyes.Pos ~= nil then
					
					originpos = eyes.Pos
					
				else
					
					originpos = ply:GetBonePosition( head ) + ang:Up() * 2
					
				end
				local normal = ( originpos - pos ):GetNormalized()
				local f = { ply }
				if ply:InVehicle() == true then f[ 2 ] = ply:GetVehicle() end
				local tr = util.TraceLine( {
					
					start = pos,
					endpos = originpos + ( normal * 16 ),
					filter = f,
					
				} )
				if tr.Hit == true then
					
					local ntr = util.TraceLine( {
						
						start = originpos,
						endpos = originpos + ( normal * 16 ),
						filter = f,
						
					} )
					local dir = ( ntr.Normal + ply:GetAimVector() ):GetNormalized()
					originpos = originpos - ( dir * ( 16 * ( 1 - ntr.Fraction ) ) )
					
				end
				
				if ply:InVehicle() == true and ply:GetVehicle().GetThirdPersonMode ~= nil and ply:GetVehicle():GetThirdPersonMode() == true then
					
					scale( Vector( 1, 1, 1 ) )
					
				else
					
					scale( Vector( 0, 0, 0 ) )
					ply:ManipulateBoneScale( head, Vector( 0, 0, 0 ) )
					
				end
				
			end
			
			drawply = true
			
		elseif head ~= nil then
			
			scale( Vector( 1, 1, 1 ) )
			
		end
		
		if ply:InVehicle() == true then
			
			local vehicle = ply:GetVehicle()
			if IsValid( vehicle ) == true and vehicle.GetThirdPersonMode ~= nil and vehicle:GetThirdPersonMode() == true then return end
			
		end
		
		return {
			
			origin = originpos,
			angles = angle,
			fov = zoom,
			znear = near,
			zfar = far,
			drawviewer = drawply,
			
		}
		
	elseif head ~= nil then
		
		scale( Vector( 1, 1, 1 ) )
		
	end
	
end )

hook.Add( "HUDShouldDraw", "ViewMod_HUDShouldDraw", function( hud )
	
	if hud ~= "CHudCrosshair" or created[ "viewmod_enable" ]:GetBool() ~= true then return end
	
	local ply = LocalPlayer()
	if GetViewEntity() ~= ply or ply:InVehicle() == true then return end
	
	if created[ "viewmod_worldmodel" ]:GetBool() == true then return false end
	if created[ "viewmod_thirdperson" ]:GetBool() == true and created[ "viewmod_oldtpaim" ]:GetBool() == true then return false end
	
end )

local function drawcrosshair( x, y )
	
	local min = math.min( ScrW(), ScrH() )
	local dist = math.Round( min * 0.01 )
	local size = math.Round( min * 0.001 )
	
	surface.SetDrawColor( 255, 255, 255, 255 )
	
	surface.DrawRect( x, y, 1, 1 )
	surface.DrawRect( x, y - dist, 1, 1 )
	surface.DrawRect( x + dist, y, 1, 1 )
	surface.DrawRect( x, y + dist, 1, 1 )
	surface.DrawRect( x - dist, y, 1, 1 )
	
end

hook.Add( "HUDPaint", "ViewMod_HUDPaint", function()
	if created[ "viewmodel_delete"]:GetBool() == true then
		LocalPlayer():DrawViewModel(false)
	else
		LocalPlayer():DrawViewModel(true)
	end
	if created[ "viewmod_enable" ]:GetBool() ~= true then return end
	if created[ "viewmod_worldmodel" ]:GetBool() ~= true and ( created[ "viewmod_thirdperson" ]:GetBool() ~= true or created[ "viewmod_oldtpaim" ]:GetBool() ~= true ) then return end
	
	local ply = LocalPlayer()
	if GetViewEntity() ~= ply or ply:InVehicle() == true then return end
	
	if prevpos == nil or prevang == nil then return end
	
	local trace = util.TraceLine( { start = prevpos, endpos = prevpos + prevang:Forward() * 32768, filter = ply } )
	
	cam.Start3D()
		
		local pos = trace.HitPos:ToScreen()
		
	cam.End3D()
	
	local weapon = ply:GetActiveWeapon()
	local dodraw = true
	if IsValid( weapon ) == true and weapon.DoDrawCrosshair ~= nil then
		
		if weapon:DoDrawCrosshair( math.Round( pos.x ), math.Round( pos.y ) ) == true then dodraw = false end
		
	end
	if dodraw == true then drawcrosshair( math.Round( pos.x ), math.Round( pos.y ) ) end
	
end )

hook.Add( "ShouldDrawLocalPlayer", "ViewMod_ShouldDrawLocalPlayer", function( ply )
	
	if created[ "viewmod_enable" ]:GetBool() ~= true or created[ "viewmod_worldmodel" ]:GetBool() ~= true then return end
	
	local wep = ply:GetActiveWeapon()
	if IsValid( wep ) == false or wep:GetClass() ~= "gmod_camera" then return true end
	
end )


----
-- ViewMod menu
----

local function ViewModPanel( Panel )
	
	local ply = LocalPlayer()
	for i = 1, #convars do
		
		if convars[ i ][ 3 ] == "CheckBox" then
			
			local button = Panel:CheckBox( convars[ i ][ 4 ], convars[ i ][ 1 ] )
			function button:OnChange()
				
				if created[ "viewmod_enable" ]:GetBool() == true then ViewModUpdate( ply:GetActiveWeapon() ) end
				
			end
			
		elseif convars[ i ][ 3 ] == "Slider" then
			
			local slider = Panel:NumSlider( convars[ i ][ 4 ], convars[ i ][ 1 ], convars[ i ][ 5 ], convars[ i ][ 6 ], 2 )
			function slider:OnChange()
				
				if created[ "viewmod_enable" ]:GetBool() == true then ViewModUpdate( ply:GetActiveWeapon() ) end
				
			end
			
		end
		
	end
	
	local reset = Panel:Button( "Reset", "viewmod_reset" )
	
	local print_ = Panel:Button( "Print convars", "viewmod_print" )
	
end

hook.Add( "PopulateToolMenu", "ViewModPanel", function()
	
	spawnmenu.AddToolMenuOption( "Options", "Player", "ViewModOptions", "ViewMod", nil, nil, ViewModPanel )
	
end )

local menu

concommand.Add( "viewmod_menu", function()
	
	if IsValid( menu ) == true then menu:Remove() end
	
	menu = vgui.Create( "DFrame" )
	menu:SetPos( ScrW() * 0.3, ScrH() * 0.2 )
	menu:SetSize( ScrW() * 0.4, ScrH() * 0.6 )
	menu:SetTitle( "ViewMod" )
	menu:SetSizable( true )
	menu:MakePopup()
	
	local Scroll = vgui.Create( "DScrollPanel" )
	Scroll:SetParent( menu )
	Scroll:Dock( FILL )
	
	local Form = vgui.Create( "DForm" )
	Form:SetParent( Scroll )
	Form:Dock( FILL )
	Form:SetName( "" )
	Form:DockPadding( 0, -ScrH() * 0.02, 0, ScrH() * 0.01 )
	
	function Form:Paint( w, h )
		
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawRect( 0, 0, w, h )
		
	end
	
	ViewModPanel( Form )
	
end )
hook.Add( "HUDDrawTargetID", "HidePlayerInfo", function()

	return false

end )