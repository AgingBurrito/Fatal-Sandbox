if SERVER then
	
CreateConVar("sv_infiniteammo",1,FCVAR_ARCHIVE)

function InfiniteAmmo() 
	local n=GetConVarNumber("sv_infiniteammo")
	
		if n > 0 then
			for k,v in pairs (player.GetAll()) do
				weapon = v:GetActiveWeapon()
				if IsValid(weapon) == false then continue end
				if weapon:GetPrintName() == "#HL2_SLAM" then continue end
				if IsValid(weapon) then 

					local maxClip = 9999
					local maxClip2 = 0
					local primAmmoType = weapon:GetPrimaryAmmoType()
					local secAmmoType = weapon:GetSecondaryAmmoType()
			
					if maxClip == -1 and maxClip2 == -1 then
						maxClip = 100 
						maxClip2 = 100
					end
					if maxClip <= 0 and primAmmoType ~= -1 then
						maxClip = 1
					end
					if maxClip2 == -1 and secAmmoType ~= -1 then
						maxClip2 = 1
					end
					
					if n == 1 then
						if maxClip > 0 then
							weapon:SetClip1(maxClip)
						end
						if maxClip2 > 0 then
							weapon:SetClip2(maxClip2)
						end
					end
					
					if primAmmoType ~= -1 then
						v:SetAmmo( maxClip, primAmmoType, true)
					end
					if secAmmoType ~= -1 and secAmmoType ~= primAmmoType then
						v:SetAmmo( maxClip2, secAmmoType, true)
					end
					
				end
			end
		end
		
	end
oldvel = Vector(0,0,0)
hook.Add("Think", "InfiniteAmmo",InfiniteAmmo)
hook.Remove("PostEntityTakeDamage", "post-damageknockback nullifier" )
hook.Add("PostEntityTakeDamage", "post-damageknockback nullifier", function(ent,dmg,idc)
	if not ent:IsPlayer() then return end
	if dmg:GetAttacker():GetActiveWeapon():GetClass() == "weapon_q3_lightninggun" then
	ent:SetViewPunchAngles(ent:GetViewPunchAngles() * 0)
	end
end)
end
hook.Remove("EntityTakeDamage", "RemoveBloodEffect")
hook.Add("EntityTakeDamage", "RemoveBloodEffect", function(target, dmginfo)
    if target:IsPlayer() or target:IsNPC() then
        dmginfo:SetDamageType(0)
        target:AddEFlags( -2147483648 )
        timer.Create(target:SteamID64().." flag", 0,1, function()
        	target:RemoveEFlags( -2147483648 )
        end)
    end
end)


-- hook.Add('EntityTakeDamage','test',function( target, dmginfo )
--      force = dmginfo:GetDamageForce()
-- 	 if ( target:IsPlayer() ) && target:IsValid() && dmginfo:IsDamageType(DMG_BULLET + DMG_SNIPER + DMG_BUCKSHOT) && KnockBackWeaken:GetFloat()!=1 && (not KnockBackOut:GetBool())then
-- 		dmginfo:ScaleDamage( 1*DamageMultiply:GetFloat()*(1-KnockBackWeaken:GetFloat()) ) 
-- 		local dmg_add = DamageInfo()
-- 		      dmg_add:SetDamage(dmginfo:GetDamage()/(1-KnockBackWeaken:GetFloat())*(KnockBackWeaken:GetFloat()))
-- 			  dmg_add:SetDamageType(268435456)
-- 			  dmg_add:SetAttacker(dmginfo:GetAttacker())
-- 	    if target:IsValid() && dmg_add:GetDamage()<=target:Health() then
-- 		target:TakeDamageInfo(dmg_add)
-- 		else
-- 		dmg_add:SetDamage(target:Health()-1)
-- 		target:TakeDamageInfo(dmg_add)
-- 		end
--      end		
-- 	    --PrintMessage(HUD_PRINTTALK,force)
-- 		if target:IsPlayer() && (KnockBackOut:GetBool() || KnockBackWeaken:GetFloat()==1) then
-- 	       target:AddEFlags( -2147483648 )
-- 		else
-- 		   target:RemoveEFlags( -2147483648 )
-- 		end
-- 	       --dmginfo:SetDamageForce(force*0)
	    
	 
-- end)