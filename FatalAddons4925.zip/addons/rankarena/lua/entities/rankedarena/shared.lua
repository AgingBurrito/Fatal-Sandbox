ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.Spawnable = true
if CLIENT then
ENT.PrintName = "aaa"
end