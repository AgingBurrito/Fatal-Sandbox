util.AddNetworkString("CustomSpawn_Set")
util.AddNetworkString("CustomSpawn_Remove")

local playerSpawns = {}

hook.Add("PlayerSay", "CustomSpawn.ChatCommands", function(ply, text)
	text = string.Trim(string.lower(text))
	if text == "!spawn" then
		playerSpawns[ply:SteamID()] = {
			pos = ply:GetPos(),
			ang = ply:EyeAngles()
		}
		ply:ChatPrint("set")
		return ""
	elseif text == "!removespawn" then
		playerSpawns[ply:SteamID()] = nil
		ply:ChatPrint("gone")
		return ""
	end
end)

hook.Add("PlayerSpawn", "CustomSpawn.OverrideSpawn", function(ply)
	local spawn = playerSpawns[ply:SteamID()]
	if spawn then
		timer.Simple(0, function()
			if IsValid(ply) then
				ply:SetPos(spawn.pos)
				ply:SetEyeAngles(Angle(spawn.ang.x, spawn.ang.y, spawn.ang.z))
			end
		end)
	end
end)