ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName  = "King"
ENT.Spawnable = true 
