if SERVER then
    hook.Add("PlayerSwitchWeapon", "spectate weapon remover", function(ply,old,new)
        if ply:GetObserverMode() == 6 then
            ply:StripWeapons()
        end
    end)
    
    hook.Add("PlayerSpawn", "cheat spectate force", function(ply)
        if ply:GetPData("cheater") == "1" then
            timer.Simple(0.3, function()
                ply:StripWeapons()
                ply:Spectate(6)
            end)
        end
    end)
    hook.Add("PlayerSay", "spectate", function(ply, txt)
        text = string.Explode(",", txt)
        if text[1] == "!spec" then
            ply:StripWeapons()
            ply:Spectate(6)
        end
        if text[1] == "!pvp" then
            if ply:GetPData("cheater") == "1" then
                ply:ChatPrint("UR A CHEATER LOLOLOLOL")
                return false
            end
            ply:Spawn()
        end
        if text[1] == "!forcespec" then
            if ply:IsSuperAdmin() then
                for k,v in pairs(player.GetAll()) do
                    print(text[2])
                    print(v:Nick())
                    if v:Nick() == text[2] then
                        v:SetPData("cheater", 1)
                        v:StripWeapons()
                        v:Spectate(6)
                    end
                end
            else
                ply:ChatPrint("ask corvus")
            end
        end
        if text[1] == "!forgive" then
            if ply:IsSuperAdmin() then
                for k,v in pairs(player.GetAll()) do
                    if v:Nick() == text[2] then
                        v:SetPData("cheater", 0)
                        v:Spawn()
                    end
                end
            else 
                ply:ChatPrint("ask corvus")
            end
        end
    end)
end

if CLIENT then

end