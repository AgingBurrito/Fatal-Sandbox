CreateClientConVar("ESPBox", 0, true, false, "toggles the box around people", 0, 1)
CreateClientConVar("ESPHitBox", 0, true, false, "Toggles hitbox ESP", 0, 1)
CreateClientConVar("ESPBox_Red", 0, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPBox_Green", 255, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPBox_Blue", 0, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPBox_Alpha", 255, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPHitBox_Red", 0, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPHitBox_Green", 255, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPHitBox_Blue", 0, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPHitBox_Alpha", 255, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPHitBox_Mat", 0, true, false, "render a texture on the hitboxes", 0, 1)
CreateClientConVar("ESPHitBox_Mat_Path", "models/props_pipes/Pipesystem01a_skin3", true, false, "hitbox material filepath")
CreateClientConVar("ESPName", 1, true, false, "toggles the box around people", 0, 1)
CreateClientConVar("ESPName_Red", 0, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPName_Green", 255, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPName_Blue", 0, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPHP", 1, true, false, "toggles the box around people", 0, 1)
CreateClientConVar("ESPHP_Red", 255, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPHP_Green", 255, true, false, "toggles the box around people", 0, 255)
CreateClientConVar("ESPHP_Blue", 255, true, false, "toggles the box around people", 0, 255)
CreateConVar("fatal_esp", 1, FCVAR_REPLICATED, "Enables or disabeles the ESP for everybody", 0, 1)
local boxmaterial = Material("phoenix_storms/bluemetal")
local boxColor = Color(
    GetConVar("ESPBox_Red"):GetInt(),
    GetConVar("ESPBox_Green"):GetInt(),
    GetConVar("ESPBox_Blue"):GetInt(),
    GetConVar("ESPBox_Alpha"):GetInt())
local function UpdateBoxColor()
    boxColor = Color(
        GetConVar("ESPBox_Red"):GetInt(),
        GetConVar("ESPBox_Green"):GetInt(),
        GetConVar("ESPBox_Blue"):GetInt(),
        GetConVar("ESPBox_Alpha"):GetInt())end
cvars.AddChangeCallback("ESPBox_Red", function() UpdateBoxColor() end)
cvars.AddChangeCallback("ESPBox_Green", function() UpdateBoxColor() end)
cvars.AddChangeCallback("ESPBox_Blue", function() UpdateBoxColor() end)
cvars.AddChangeCallback("ESPBox_Alpha", function() UpdateBoxColor() end)
local hitBoxColor = Color(
    GetConVar("ESPHitBox_Red"):GetInt(),
    GetConVar("ESPHitBox_Green"):GetInt(),
    GetConVar("ESPHitBox_Blue"):GetInt(),
    GetConVar("ESPHitBox_Alpha"):GetInt())
local function UpdateHitBoxColor()
    hitBoxColor = Color(
        GetConVar("ESPHitBox_Red"):GetInt(),
        GetConVar("ESPHitBox_Green"):GetInt(),
        GetConVar("ESPHitBox_Blue"):GetInt(),
        GetConVar("ESPHitBox_Alpha"):GetInt())end
cvars.AddChangeCallback("ESPHitBox_Red", function() UpdateHitBoxColor() end)
cvars.AddChangeCallback("ESPHitBox_Green", function() UpdateHitBoxColor() end)
cvars.AddChangeCallback("ESPHitBox_Blue", function() UpdateHitBoxColor() end)
cvars.AddChangeCallback("ESPHitBox_Alpha", function() UpdateHitBoxColor() end)
cvars.AddChangeCallback("ESPHitBox_Mat_Path", function(name,old,new) boxmaterial = Material(new) end)

local ESPNameColor = Color(
    GetConVar("ESPName_Red"):GetInt(),
    GetConVar("ESPName_Green"):GetInt(),
    GetConVar("ESPName_Blue"):GetInt())
local function UpdateESPNameColor()
    ESPNameColor = Color(
    GetConVar("ESPName_Red"):GetInt(),
    GetConVar("ESPName_Green"):GetInt(),
    GetConVar("ESPName_Blue"):GetInt())    
end
cvars.AddChangeCallback("ESPName_Red", function() UpdateESPNameColor() end)
cvars.AddChangeCallback("ESPName_Green", function() UpdateESPNameColor() end)
cvars.AddChangeCallback("ESPName_Blue", function() UpdateESPNameColor() end)
hook.Add( "AddToolMenuCategories", "CustomCategory", function()
    spawnmenu.AddToolCategory( "Options", "Fatal Sandbox", "#Fatal Sandbox" )
end )

hook.Add( "PopulateToolMenu", "CustomMenuSettings", function()
    spawnmenu.AddToolMenuOption( "Options", "Fatal Sandbox", "ESP", "#ESP", "", "", function( panel )
        panel:ClearControls()
        panel:CheckBox("ESPBox", "ESPBox")
        panel:CheckBox("ESPHitBox", "ESPHitBox")
        panel:CheckBox("ESPName", "ESPName")
        panel:CheckBox("playermodels", "playermodels")
        panel:ColorPicker("Box Color", "ESPBox_Red","ESPBox_Green","ESPBox_Blue","ESPBox_Alpha" )
        panel:ColorPicker("Hit Box Color", "ESPHitBox_Red","ESPHitBox_Green","ESPHitBox_Blue","ESPHitBox_Alpha" )
        panel:ColorPicker("Name Color", "ESPName_Red", "ESPName_Green", "ESPName_Blue")
        -- Add stuff here
    end )
end )
local red = Color(255,0,0)
local green = Color(0,255,0)
local black = Color(0,0,0)
local white = Color(255,255,255)
hook.Add('HUDPaint', 'AESP.Info', function()
    if GetConVar("fatal_esp"):GetInt() == 0 then return end
    for k, v in ipairs(player.GetAll()) do
        if v == LocalPlayer() then continue end
        if v:GetObserverMode() != 0 then continue end
        local name = GetConVar("ESPName"):GetInt()
        local pos = v:GetPos() + Vector(0,0,75)
        local healthpos = v:GetPos() + Vector(0,0,80)
        pos = pos:ToScreen()
        healthpos = healthpos:ToScreen()
        if name == 1 then 
            draw.SimpleTextOutlined(v:Name(),"DermaDefault",pos.x,pos.y, ESPNameColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black)
            draw.SimpleTextOutlined(v:Health(),"DermaDefault",healthpos.x,healthpos.y, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black)
        end
        if LocalPlayer():GetNWString("TLD_PlayMode") == "Spec" then 
            draw.SimpleTextOutlined(v:Health(),"DermaDefault",pos.x,healthpos.y, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black)
        end
    end
end)
local function DrawSolidBox(pos, ang, mins, maxs, col)
    render.SetColorMaterial()
    render.SuppressEngineLighting(true)
    render.SetColorModulation(
        col.r / 255,
        col.g / 255,
        col.b / 255
        )
    render.SetBlend(col.a / 255)
    local corners = {
        Vector(mins.x, mins.y, mins.z),
        Vector(maxs.x, mins.y, mins.z),
        Vector(maxs.x, maxs.y, mins.z),
        Vector(mins.x, maxs.y, mins.z),
        Vector(mins.x, mins.y, maxs.z),
        Vector(maxs.x, mins.y, maxs.z),
        Vector(maxs.x, maxs.y, maxs.z),
        Vector(mins.x, maxs.y, maxs.z),
    }

    local matrix = Matrix()
    matrix:SetTranslation(pos)
    matrix:SetAngles(ang)

    cam.PushModelMatrix(matrix)
        render.SetColorMaterial()
        render.DrawQuadEasy((corners[1] + corners[2] + corners[3] + corners[4]) / 4, Vector(0,0,-1), maxs.x - mins.x, maxs.y - mins.y, col, 0) -- Bottom
        render.DrawQuadEasy((corners[5] + corners[6] + corners[7] + corners[8]) / 4, Vector(0,0,1), maxs.x - mins.x, maxs.y - mins.y, col, 0)  -- Top

        render.DrawQuadEasy((corners[1] + corners[2] + corners[6] + corners[5]) / 4, Vector(0,-1,0), maxs.x - mins.x, maxs.z - mins.z, col, 0) -- Y-
        render.DrawQuadEasy((corners[3] + corners[4] + corners[8] + corners[7]) / 4, Vector(0,1,0), maxs.x - mins.x, maxs.z - mins.z, col, 0)  -- Y+

        render.DrawQuadEasy((corners[2] + corners[3] + corners[7] + corners[6]) / 4, Vector(1,0,0), maxs.y - mins.y, maxs.z - mins.z, col, 0)  -- X+
        render.DrawQuadEasy((corners[1] + corners[4] + corners[8] + corners[5]) / 4, Vector(-1,0,0), maxs.y - mins.y, maxs.z - mins.z, col, 0) -- X-
    cam.PopModelMatrix()
    cam.IgnoreZ(true)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end
local function drawBoundingBox(ply)
    local ang = Angle(0, ply:EyeAngles().y, 0)
    local mins = ply:OBBMins()
    local maxs = ply:OBBMaxs()
    DrawSolidBox(ply:GetPos(), ang, mins, maxs, boxColor)
end
local function drawHitBox(ply)
    local hitboxCount = ply:GetHitBoxCount(0)
    for hitboxIndex = 0, hitboxCount - 1 do
        local mins, maxs = ply:GetHitBoxBounds(hitboxIndex, 0)
        local matrix = ply:GetBoneMatrix(ply:GetHitBoxBone(hitboxIndex, 0))
        if matrix then
            render.SuppressEngineLighting(true)
            render.SetMaterial(boxmaterial)
            render.DrawBox(matrix:GetTranslation(), matrix:GetAngles(), mins, maxs, hitBoxColor)
            render.SuppressEngineLighting(false)
        end
    end
end
hook.Remove("PreDrawTranslucentRenderables", "Boxxie")
hook.Add("PreDrawTranslucentRenderables", "Boxxie", function()
    if GetConVar("fatal_esp"):GetInt() == 0 then return end
    if GetConVar("ESPBox") == 0 && GetConVar("ESPHitBox") == 0 then return end
    for _,v in pairs(player.GetAll()) do
        if v == LocalPlayer() then continue end
        if v:GetObserverMode() != 0 then continue end
        if not v:Alive() then continue end
        if GetConVar("ESPBox"):GetBool() then
            drawBoundingBox(v)
        end
        if  GetConVar("ESPHitBox"):GetBool() then
            drawHitBox(v)
        end
    end
    
    cam.IgnoreZ(false)
end)
CreateClientConVar("playermodels", 1, true, false, "Toggles player model rendering", 0, 1)

hook.Add("PrePlayerDraw", "ConditionalHide", function(ply)
    if !GetConVar("playermodels"):GetBool() then
        return true
    end
end)